# MP Report

## Team

- Name(s): Ganesh Prasad Chandra Shekar
- AID(s): A20557831

## Self-Evaluation Checklist

Tick the boxes (i.e., fill them with 'X's) that apply to your submission:

- [x] The app builds without error
- [x] I tested the app in at least one of the following platforms (check all that apply):
  - [x] iOS simulator / MacOS
  - [ ] Android emulator
  - [x] Google Chrome
  - [ ] Windows Edge
- [x] The page displays correctly in a window of at least 1024x768 pixels
- [x] The layout contains at least 4 distinct sections
- [x] The layout makes use of the required widgets
- [x] The page uses at least three images
- [x] The page utilizes at least one nested row/column widget
- [x] The implementation uses a data model class to represent user information

## Summary and Reflection

When tackling this app, I made several key implementation decisions that really shaped the final product. The biggest one was creating a comprehensive data model that separated all the content from the UI components. This wasn't just about clean code - it made the whole app way more maintainable and flexible. I structured the data models to mirror real-world relationships: a main TrooperProfile class that contains lists of Missions, Connections, Groups, and Gear.

I decided to use a consistent visual theme across all sections with gradients and semi-transparent overlays, but gave each section its own distinct color scheme - blue for missions, indigo for connections and groups, and purple for the gear arsenal. This helped create visual separation while maintaining cohesiveness. The profile overview section got special treatment with a full-width hero image and overlay text to create that impactful first impression.

One thing I really focused on was making the components reusable. Each section takes in its relevant data through props rather than hardcoding anything. This means you could easily repurpose this app for different characters or profiles just by passing in different data. This also made the app more maintainable and flexible.

Reflection:

Building this app was actually pretty enjoyable! I particularly liked designing the visual hierarchy and crafting those smooth gradient transitions between sections. The most satisfying part was seeing how clean the code became after refactoring everything to use the data models - it's so much more organized now.

The trickiest part was probably balancing between making the components flexible enough to handle different data while still maintaining a consistent look and feel. I had to think carefully about how to structure the data models so they'd be comprehensive enough without being overly complex. That said, the refactoring process taught me a lot about the importance of good data architecture in Flutter apps.

If I had more time, I'd probably add some animations between sections and maybe implement a detail view for when you tap on missions or gear items. I'd also like to add some interactivity, like the ability to edit stats or add new missions. But overall, I'm pretty happy with how it turned out - it's clean, maintainable, and looks pretty sharp!
