import 'package:flutter/material.dart';
import '../views/trooper_models.dart';
import '../views/profile_overview.dart';
import '../views/mission_log.dart';
import '../views/connections.dart';
import '../views/groups.dart';
import '../views/gear_arsenal.dart';

void main() {
  runApp(MaterialApp(
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.dark(
        primary: Colors.blue,
        secondary: Colors.lightBlue,
      ),
    ),
    home: TrooperProfilePage(profile: trooperProfileData),
  ));
}

class TrooperProfilePage extends StatelessWidget {
  final TrooperProfile profile;

  const TrooperProfilePage({
    Key? key,
    required this.profile,
  }) : super(key: key);

  @override
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Image.asset(
          'assets/images/star_wars_logo.png',
          height: 40,
          fit: BoxFit.contain,
        ),
        centerTitle: true,
      ),
      body: ListView(
        children: [
          ProfileOverview(profile: profile),
          MissionLogSection(missions: profile.missions),
          ConnectionsSection(connections: profile.connections),
          GroupsSection(groups: profile.groups),
          GearArsenalSection(arsenal: profile.arsenal),
        ],
      ),
    );
  }
}
