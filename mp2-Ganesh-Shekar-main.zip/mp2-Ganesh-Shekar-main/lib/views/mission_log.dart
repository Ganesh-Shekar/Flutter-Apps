import 'package:flutter/material.dart';
import './trooper_models.dart';

class MissionLogSection extends StatelessWidget {
  final List<Mission> missions;

  const MissionLogSection({
    Key? key,
    required this.missions,
  }) : super(key: key);

  String _formatDate(DateTime date) {
    final months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December'
    ];
    return '${months[date.month - 1]} ${date.day}, ${date.year}';
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(16),
      constraints: BoxConstraints(maxWidth: 600),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.blue.shade900, Colors.black87],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.blue.withOpacity(0.3),
            spreadRadius: 2,
            blurRadius: 10,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHeader(),
            SizedBox(height: 20),
            ...missions.map((mission) => _buildMissionCard(mission)),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(Icons.rocket_launch, color: Colors.blue.shade300),
        SizedBox(width: 10),
        Flexible(
          child: Text(
            'Mission Log',
            style: TextStyle(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.5,
            ),
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }

  Widget _buildMissionCard(Mission mission) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.1),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: Colors.blue.shade400.withOpacity(0.5),
          width: 1,
        ),
      ),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    mission.name,
                    style: TextStyle(
                      color: Colors.blue.shade300,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                Text(
                  _formatDate(mission.date),
                  style: TextStyle(
                    color: Colors.blue.shade200,
                    fontSize: 14,
                  ),
                ),
              ],
            ),
            SizedBox(height: 12),
            _buildMissionDetail('Objective', mission.objective),
            SizedBox(height: 8),
            _buildMissionDetail('Outcome', mission.outcome),
          ],
        ),
      ),
    );
  }

  Widget _buildMissionDetail(String label, String content) {
    return Text(
      '$label: $content',
      style: TextStyle(color: Colors.white70),
      overflow: TextOverflow.ellipsis,
      maxLines: 2,
    );
  }
}
