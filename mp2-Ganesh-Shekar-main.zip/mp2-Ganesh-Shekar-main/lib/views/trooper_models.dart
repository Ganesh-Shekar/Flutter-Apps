class TrooperProfile {
  final String name;
  final String title;
  final String description;
  final Map<String, int> stats;
  final List<Mission> missions;
  final List<Connection> connections;
  final List<Group> groups;
  final List<Gear> arsenal;

  TrooperProfile({
    required this.name,
    required this.title,
    required this.description,
    required this.stats,
    required this.missions,
    required this.connections,
    required this.groups,
    required this.arsenal,
  });
}

class Mission {
  final String name;
  final DateTime date;
  final String objective;
  final String outcome;

  Mission({
    required this.name,
    required this.date,
    required this.objective,
    required this.outcome,
  });
}

class Connection {
  final String name;
  final String role;
  final String description;
  final String imagePath;

  Connection({
    required this.name,
    required this.role,
    required this.description,
    required this.imagePath,
  });
}

class Group {
  final String name;
  final String description;
  final String imagePath;

  Group({
    required this.name,
    required this.description,
    required this.imagePath,
  });
}

class Gear {
  final String name;
  final String description;
  final String feature;
  final String imagePath;

  Gear({
    required this.name,
    required this.description,
    required this.feature,
    required this.imagePath,
  });
}

// Data initialization
final trooperProfileData = TrooperProfile(
  name: 'Star Trooper',
  title: 'Galactic Defender of Sector 7',
  description:
      'Protector of the cosmos, sworn to uphold peace and justice across the galaxy.',
  stats: {
    'Strength': 4,
    'Agility': 5,
    'Intelligence': 4,
    'Leadership': 5,
  },
  missions: [
    Mission(
      name: 'Operation Asteroid Shield',
      date: DateTime(1978, 5, 18),
      objective: 'Neutralize a rogue asteroid threatening Planet Xion',
      outcome:
          'Successfully destroyed the asteroid using a high-powered plasma cannon',
    ),
    Mission(
      name: 'Zorvian Rescue',
      date: DateTime(1981, 8, 13),
      objective: 'Rescue hostages from Zorvian pirates',
      outcome: 'All hostages rescued unharmed',
    ),
  ],
  connections: [
    Connection(
      name: 'Captain Nova',
      role: 'Mentor and Commander',
      description: 'A true leader who inspires courage in every mission',
      imagePath: 'assets/images/captain_nova.jpeg',
    ),
    Connection(
      name: 'Darth Vader',
      role: 'The Dark Lord of the Sith',
      description: 'A powerful and cunning adversary',
      imagePath: 'assets/images/darth_wader.png',
    ),
  ],
  groups: [
    Group(
      name: 'Galactic Defense Alliance',
      description: 'Elite team of defenders protecting the galaxy',
      imagePath: 'assets/images/gallactic.png',
    ),
    Group(
      name: 'Laser Blaster Enthusiasts',
      description: 'Tips and tricks for energy-based weaponry',
      imagePath: 'assets/images/boha.png',
    ),
  ],
  arsenal: [
    Gear(
      name: 'Plasma Blaster X-9000',
      description: 'State-of-the-art energy weapon with pinpoint accuracy',
      feature: 'Heat-seeking projectiles',
      imagePath: 'assets/images/plasma_blaster.png',
    ),
    Gear(
      name: 'Starshield Mk II',
      description: 'Lightweight yet durable energy shield',
      feature: 'Expandable protection field',
      imagePath: 'assets/images/starshield.jpg',
    ),
    Gear(
      name: 'Stealth Module V3',
      description: 'Advanced cloaking device',
      feature: 'Sound-dampening technology',
      imagePath: 'assets/images/stealth_module.png',
    ),
  ],
);
