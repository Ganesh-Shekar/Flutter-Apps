import 'package:flutter/material.dart';
import './trooper_models.dart';

class GearArsenalSection extends StatelessWidget {
  final List<Gear> arsenal;

  const GearArsenalSection({
    Key? key,
    required this.arsenal,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.purple.shade900, Colors.black87],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.purple.withOpacity(0.3),
            spreadRadius: 2,
            blurRadius: 10,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHeader(),
            SizedBox(height: 20),
            ...arsenal.map((gear) => _buildGearCard(gear)),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        Icon(Icons.security, color: Colors.purple.shade300),
        SizedBox(width: 10),
        Text(
          'Gear Arsenal',
          style: TextStyle(
            color: Colors.white,
            fontSize: 24,
            fontWeight: FontWeight.bold,
            letterSpacing: 1.5,
          ),
        ),
      ],
    );
  }

  Widget _buildGearCard(Gear gear) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.1),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: Colors.purple.shade400.withOpacity(0.5),
          width: 1,
        ),
      ),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    image: DecorationImage(
                      image: AssetImage(gear.imagePath),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: Text(
                    gear.name,
                    style: TextStyle(
                      color: Colors.purple.shade200,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 12),
            Text(
              gear.description,
              style: TextStyle(color: Colors.white70),
            ),
            SizedBox(height: 8),
            _buildFeatureTag(gear.feature),
          ],
        ),
      ),
    );
  }

  Widget _buildFeatureTag(String feature) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 4, horizontal: 8),
      decoration: BoxDecoration(
        color: Colors.purple.shade800.withOpacity(0.3),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Text(
        'Special Feature: $feature',
        style: TextStyle(
          color: Colors.purple.shade200,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }
}
