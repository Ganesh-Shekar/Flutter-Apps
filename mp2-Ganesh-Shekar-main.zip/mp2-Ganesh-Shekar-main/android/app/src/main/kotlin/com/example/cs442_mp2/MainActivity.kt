package com.example.cs442_mp2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
