# MP Report

## Team

- Name: Ganesh Prasad Chandra Shekar
- AID: A20557831

## Self-Evaluation Checklist

Tick the boxes (i.e., fill them with 'X's) that apply to your submission:

- [x] The app builds without error
- [x] I tested the app in at least one of the following platforms (check all
      that apply):
  - [x] iOS simulator / MacOS
  - [ ] Android emulator
  - [ ] Google Chrome
- [x] The dice rolling mechanism works correctly
- [x] The scorecard works correctly
- [x] Scores are correctly calculated for all categories
- [x] The game end condition is correctly implemented, and the final score is
      correctly displayed
- [x] The game state is reset when the user dismisses the final score
- [x] The implementation separates layout from data, involving the use of data
      model classes separate from custom widgets

## Summary and Reflection

For this Yahtzee implementation, I made several key architectural decisions to ensure clean separation of concerns. I structured the app using distinct data models for game state and scoring logic, keeping them separate from the UI components. The UI was broken down into modular widgets to handle different aspects of the game like dice display, scoring sections, and game controls. I implemented state management using StatefulWidgets to effectively manage the game's various states including dice rolls, holds, and score calculations.

The most engaging aspect of this MP was designing the scoring logic and implementing the dice rolling mechanics. Working with Flutter's animation system for dice rolls was particularly interesting. The challenging part was ensuring proper state management across multiple widget trees and handling edge cases in score calculations. Looking back. Overall, this project significantly improved my understanding of Flutter's widget lifecycle and state management patterns.
