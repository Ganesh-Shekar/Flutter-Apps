import 'package:flutter/foundation.dart';
import 'package:collection/collection.dart';

enum ScoreCategory {
  ones("Ones"),
  twos("Twos"),
  threes("Threes"),
  fours("Fours"),
  fives("Fives"),
  sixes("Sixes"),
  threeOfAKind("Three of a Kind"),
  fourOfAKind("Four of a Kind"),
  fullHouse("Full House"),
  smallStraight("Small Straight"),
  largeStraight("Large Straight"),
  yahtzee("Yahtzee"),
  chance("Chance");

  const ScoreCategory(this.name);
  final String name;
}

class ScoreCard with ChangeNotifier {
  final Map<ScoreCategory, int?> _scores = {
    for (var category in ScoreCategory.values) category: null
  };

  int? operator [](ScoreCategory category) => _scores[category];

  bool get completed => _scores.values.whereNotNull().length == _scores.length;

  int get total => _scores.values.whereNotNull().sum;

  void clear() {
    _scores.forEach((key, _) => _scores[key] = null);
    notifyListeners();
  }

  void registerScore(ScoreCategory category, List<int> dice) {
    if (_scores[category] != null) throw Exception('Category already used');

    final uniqueVals = dice.toSet();
    switch (category) {
      case ScoreCategory.ones:
      case ScoreCategory.twos:
      case ScoreCategory.threes:
      case ScoreCategory.fours:
      case ScoreCategory.fives:
      case ScoreCategory.sixes:
        final value = category.index + 1;
        _scores[category] = dice.where((d) => d == value).sum;
        break;
      case ScoreCategory.threeOfAKind:
        _scores[category] =
            dice.any((d) => dice.where((val) => val == d).length >= 3)
                ? dice.sum
                : 0;
        break;
      case ScoreCategory.fourOfAKind:
        _scores[category] =
            dice.any((d) => dice.where((val) => val == d).length >= 4)
                ? dice.sum
                : 0;
        break;
      case ScoreCategory.fullHouse:
        _scores[category] = (uniqueVals.length == 2 &&
                dice.any((d) => dice.where((val) => val == d).length == 3))
            ? 25
            : 0;
        break;
      case ScoreCategory.smallStraight:
        _scores[category] = (uniqueVals.containsAll({1, 2, 3, 4}) ||
                uniqueVals.containsAll({2, 3, 4, 5}) ||
                uniqueVals.containsAll({3, 4, 5, 6}))
            ? 30
            : 0;
        break;
      case ScoreCategory.largeStraight:
        _scores[category] = (uniqueVals.containsAll({1, 2, 3, 4, 5}) ||
                uniqueVals.containsAll({2, 3, 4, 5, 6}))
            ? 40
            : 0;
        break;
      case ScoreCategory.yahtzee:
        _scores[category] = (uniqueVals.length == 1) ? 50 : 0;
        break;
      case ScoreCategory.chance:
        _scores[category] = dice.sum;
        break;
    }
    notifyListeners();
  }
}
