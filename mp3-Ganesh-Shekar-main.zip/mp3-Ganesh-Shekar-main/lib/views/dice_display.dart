import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/dice.dart';

class DiceDisplay extends StatelessWidget {
  const DiceDisplay({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        constraints: const BoxConstraints(maxWidth: 500), // Constrain max width
        child: Row(
          // Use Row instead of Wrap
          mainAxisAlignment: MainAxisAlignment.spaceEvenly, // Even spacing
          children: List.generate(5, (index) => _Die(index: index)),
        ),
      ),
    );
  }
}

// class _Die extends StatelessWidget {
//   final int index;
//   const _Die({required this.index});

//   @override
//   Widget build(BuildContext context) {
//     final dice = context.watch<Dice>();
//     final value = dice[index];
//     final isHeld = dice.isHeld(index);
//     return GestureDetector(
//       onTap: () => dice.toggleHold(index),
//       child: Container(
//         width: 60,
//         height: 60,
//         decoration: BoxDecoration(
//           color: isHeld ? Colors.blue[200] : Colors.grey[300],
//           borderRadius: BorderRadius.circular(10),
//           border: Border.all(color: Colors.black, width: 2),
//           boxShadow: [
//             BoxShadow(
class _Die extends StatelessWidget {
  final int index;
  const _Die({required this.index});

  @override

  /// Builds a widget to display a die with an optional value.
  ///
  /// The widget is a [GestureDetector] which toggles the held state of the die
  /// when tapped.  The die's value is displayed in the center of the die as a bold, white number. If the die
  /// doesn't have a value, a question mark is displayed.
  Widget build(BuildContext context) {
    final dice = context.watch<Dice>();
    final value = dice[index];
    final isHeld = dice.isHeld(index);

    return GestureDetector(
      onTap: value != null ? () => dice.toggleHold(index) : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        width: 50,
        height: 50,
        decoration: BoxDecoration(
          color: isHeld ? Colors.purple[300] : Color.fromRGBO(255, 140, 0, 0.8),
          borderRadius: BorderRadius.circular(15),
          border: Border.all(
              color: isHeld ? Colors.purple[700]! : Colors.orange[700]!,
              width: 3),
          boxShadow: [
            BoxShadow(
              color: isHeld
                  ? Colors.purple.withOpacity(0.5)
                  : Colors.orange.withOpacity(0.5),
              blurRadius: 8,
              spreadRadius: 2,
              offset: const Offset(3, 3),
            ),
          ],
        ),
        child: Center(
          child: Text(
            value?.toString() ?? '?',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color:
                  value != null ? Colors.white : Colors.white.withOpacity(0.5),
              shadows: [
                Shadow(
                  color: Colors.black.withOpacity(0.3),
                  offset: const Offset(2, 2),
                  blurRadius: 2,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
