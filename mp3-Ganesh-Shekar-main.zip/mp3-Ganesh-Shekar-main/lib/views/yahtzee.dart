import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/dice.dart';
import '../models/scorecard.dart';
import 'dice_display.dart';
import 'scorecard_display.dart';

class Yahtzee extends StatelessWidget {
  const Yahtzee({super.key});

  @override
  /// Builds the main game screen, which includes the header, dice display,
  /// scorecard display, and roll button. If the game is over, it also shows
  /// a dialog with the final score and a "New Game" button.
  Widget build(BuildContext context) {
    final scorecard = context.watch<ScoreCard>();

    if (scorecard.completed) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text('Game Over!'),
            content: Text('Final Score: ${scorecard.total}'),
            actions: [
              TextButton(
                onPressed: () {
                  scorecard.clear();
                  context.read<Dice>().clear();
                  Navigator.pop(context);
                },
                child: const Text('New Game'),
              ),
            ],
          ),
        );
      });
    }

    return Scaffold(
      body: LayoutBuilder(
        builder: (context, constraints) {
          return Center(
            child: ConstrainedBox(
              constraints: BoxConstraints(maxWidth: 1280),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  children: [
                    _buildHeader(context),
                    const Expanded(
                      flex: 2,
                      child: DiceDisplay(),
                    ),
                    const Expanded(
                      flex: 5,
                      child: ScorecardDisplay(),
                    ),
                    _buildRollButton(context),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return SafeArea(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.purple.shade400, Colors.blue.shade600],
              ),
              borderRadius: BorderRadius.circular(25),
              boxShadow: [
                BoxShadow(
                  color: Colors.purple.withOpacity(0.3),
                  spreadRadius: 2,
                  blurRadius: 8,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: Row(
              children: [
                const Icon(Icons.casino, color: Colors.white, size: 24),
                const SizedBox(width: 8),
                Text(
                  'Rolls Left: ${3 - context.watch<Dice>().currentRolls}',
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    shadows: [
                      Shadow(
                          color: Colors.black26,
                          offset: Offset(1, 1),
                          blurRadius: 2)
                    ],
                  ),
                ),
              ],
            ),
          ),
          const Expanded(child: SizedBox()),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.green.shade400, Colors.teal.shade600],
              ),
              borderRadius: BorderRadius.circular(25),
              boxShadow: [
                BoxShadow(
                  color: Colors.green.withOpacity(0.3),
                  spreadRadius: 2,
                  blurRadius: 8,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: Row(
              children: [
                const Icon(Icons.stars, color: Colors.white, size: 24),
                const SizedBox(width: 8),
                Text(
                  'Score: ${context.watch<ScoreCard>().total}',
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    shadows: [
                      Shadow(
                          color: Colors.black26,
                          offset: Offset(1, 1),
                          blurRadius: 2)
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRollButton(BuildContext context) {
    final dice = context.read<Dice>();
    return Container(
      margin: const EdgeInsets.only(top: 16.0, bottom: 8.0),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: dice.currentRolls < 3
              ? [Colors.orange.shade400, Colors.red.shade600]
              : [Colors.grey.shade400, Colors.grey.shade600],
        ),
        borderRadius: BorderRadius.circular(35),
        boxShadow: [
          BoxShadow(
            color: dice.currentRolls < 3
                ? Colors.orange.withOpacity(0.6)
                : Colors.transparent,
            spreadRadius: 4,
            blurRadius: 15,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: ElevatedButton(
        onPressed: dice.currentRolls < 3 ? dice.roll : null,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          padding: const EdgeInsets.symmetric(horizontal: 60, vertical: 30),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(35),
            side: BorderSide(
              color: dice.currentRolls < 3
                  ? Colors.orange.shade300
                  : Colors.grey.shade500,
              width: 3,
            ),
          ),
        ),
        child: Text(
          '🎲 ROLL!',
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.w900,
            color: Colors.white,
            shadows: dice.currentRolls < 3
                ? [
                    const Shadow(
                      color: Colors.black54,
                      offset: Offset(2, 2),
                      blurRadius: 4,
                    ),
                  ]
                : [],
          ),
        ),
      ),
    );
  }
}
