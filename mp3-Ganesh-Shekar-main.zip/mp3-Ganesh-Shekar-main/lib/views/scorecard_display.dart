import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/scorecard.dart';
import '../models/dice.dart';

class ScorecardDisplay extends StatelessWidget {
  const ScorecardDisplay({super.key});

  @override

  /// Builds the UI for displaying the scorecard. This widget listens to changes
  /// in the ScoreCard and Dice providers to update the UI accordingly. It
  /// adapts the layout based on the screen width using a responsive design
  /// approach. The _buildResponsiveLayout method is called to
  /// generate the appropriate layout for the given screen size.

  Widget build(BuildContext context) {
    final scorecard = context.watch<ScoreCard>();
    final dice = context.watch<Dice>();

    // Get all categories
    final allCategories = List<ScoreCategory>.from(ScoreCategory.values);

    return LayoutBuilder(
      builder: (context, constraints) {
        // For very large screens, center-align with constrained width
        final maxContentWidth = 1200.0;
        final isLargeScreen = constraints.maxWidth > maxContentWidth;

        // Center alignment for larger screens
        return Center(
          child: Container(
            constraints: BoxConstraints(maxWidth: maxContentWidth),
            padding:
                EdgeInsets.symmetric(horizontal: isLargeScreen ? 16.0 : 0.0),
            child: _buildResponsiveLayout(
                context, allCategories, scorecard, dice, constraints.maxWidth),
          ),
        );
      },
    );
  }

  // Determine and build the appropriate layout based on screen width
  Widget _buildResponsiveLayout(
      BuildContext context,
      List<ScoreCategory> allCategories,
      ScoreCard scorecard,
      Dice dice,
      double width) {
    if (width >= 900) {
      // Wide layout - 6-6-1 arrangement with bigger tiles
      return _buildWideLayout(context, allCategories, scorecard, dice);
    } else if (width >= 600) {
      // Medium layout - 5-5-3 arrangement
      return _buildMediumLayout(context, allCategories, scorecard, dice);
    } else {
      // Narrow layout - 4-4-4-1 arrangement
      return _buildNarrowLayout(context, allCategories, scorecard, dice);
    }
  }
  // Narrow layout (mobile or small screens) - 4-4-4-1
  Widget _buildNarrowLayout(BuildContext context,
      List<ScoreCategory> allCategories, ScoreCard scorecard, Dice dice) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // First row - 4 categories with smaller tiles
        _buildCategoryRow(context, allCategories.sublist(0, 4), scorecard, dice,
            TileSize.small),

        // Second row - 4 categories with smaller tiles
        _buildCategoryRow(context, allCategories.sublist(4, 8), scorecard, dice,
            TileSize.small),

        // Third row - 4 categories with smaller tiles
        _buildCategoryRow(context, allCategories.sublist(8, 12), scorecard,
            dice, TileSize.small),

        // Last row - Chance category centered with smaller tile
        Padding(
          padding: const EdgeInsets.only(top: 2),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                width: 120, // Reduced from 150
                child: _CategoryTile(
                  category: ScoreCategory.chance,
                  score: scorecard[ScoreCategory.chance],
                  active: dice.currentRolls > 0 &&
                      scorecard[ScoreCategory.chance] == null,
                  size: TileSize.small,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
  // Medium layout (tablets) - 5-5-3
  Widget _buildMediumLayout(BuildContext context,
      List<ScoreCategory> allCategories, ScoreCard scorecard, Dice dice) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // First row - 5 categories
        _buildCategoryRow(context, allCategories.sublist(0, 5), scorecard, dice,
            TileSize.medium),

        // Second row - 5 categories
        _buildCategoryRow(context, allCategories.sublist(5, 10), scorecard,
            dice, TileSize.medium),

        // Third row - 3 categories (includes Chance) with spacers for alignment
        Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Spacer(flex: 1),
              ...allCategories
                  .sublist(10, 12)
                  .map((category) => Expanded(
                        flex: 2,
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 4),
                          child: _CategoryTile(
                            category: category,
                            score: scorecard[category],
                            active: dice.currentRolls > 0 &&
                                scorecard[category] == null,
                            size: TileSize.medium,
                          ),
                        ),
                      ))
                  .toList(),
              Expanded(
                flex: 2,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: _CategoryTile(
                    category: ScoreCategory.chance,
                    score: scorecard[ScoreCategory.chance],
                    active: dice.currentRolls > 0 &&
                        scorecard[ScoreCategory.chance] == null,
                    size: TileSize.medium,
                  ),
                ),
              ),
              const Spacer(flex: 1),
            ],
          ),
        ),
      ],
    );
  }

  // Wide layout (desktop) - 6-6-1
  Widget _buildWideLayout(BuildContext context,
      List<ScoreCategory> allCategories, ScoreCard scorecard, Dice dice) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // First row - 6 categories
        _buildCategoryRow(context, allCategories.sublist(0, 6), scorecard, dice,
            TileSize.large),

        // Second row - 6 categories
        _buildCategoryRow(context, allCategories.sublist(6, 12), scorecard,
            dice, TileSize.large),

        // Last row - just the Chance category centered
        Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                width: 220, // Wider for the larger layout
                child: _CategoryTile(
                  category: ScoreCategory.chance,
                  score: scorecard[ScoreCategory.chance],
                  active: dice.currentRolls > 0 &&
                      scorecard[ScoreCategory.chance] == null,
                  size: TileSize.large,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // Helper method to build a row of category tiles
  Widget _buildCategoryRow(BuildContext context, List<ScoreCategory> categories,
      ScoreCard scorecard, Dice dice, TileSize size) {
    final padding = size == TileSize.large
        ? 6.0
        : size == TileSize.medium
            ? 4.0
            : 2.0;

    return Padding(
      padding: EdgeInsets.only(bottom: padding),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: categories.map((category) {
          return Expanded(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: padding / 2),
              child: _CategoryTile(
                category: category,
                score: scorecard[category],
                active: dice.currentRolls > 0 && scorecard[category] == null,
                size: size,
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}

// Enum to manage different tile sizes
enum TileSize { small, medium, large }

class _CategoryTile extends StatelessWidget {
  final ScoreCategory category;
  final int? score;
  final bool active;
  final TileSize size;

  const _CategoryTile({
    required this.category,
    required this.score,
    required this.active,
    this.size = TileSize.medium,
  });

  Color _getTileColor() {
    if (active) return const Color(0xFF4CAF50); // Material Green
    if (score != null)
      return const Color(0xFFD1D9FF); // A richer, more visible mint blue
    return Colors.grey.shade200;
  }

  @override
  Widget build(BuildContext context) {
    // Size-dependent parameters
    final double verticalPadding = size == TileSize.large
        ? 16.0
        : size == TileSize.medium
            ? 8.0
            : 6.0;
    final double horizontalPadding = size == TileSize.large
        ? 10.0
        : size == TileSize.medium
            ? 4.0
            : 2.0;
    final double fontSize = size == TileSize.large
        ? 16.0
        : size == TileSize.medium
            ? 12.0
            : 11.0;
    final double scoreSize = size == TileSize.large
        ? 18.0
        : size == TileSize.medium
            ? 13.0
            : 12.0;
    final double spacing = size == TileSize.large
        ? 8.0
        : size == TileSize.medium
            ? 4.0
            : 2.0;
    final double elevation = size == TileSize.large
        ? 4.0
        : size == TileSize.medium
            ? 3.0
            : 2.0;
    final double borderRadius = size == TileSize.large
        ? 12.0
        : size == TileSize.medium
            ? 10.0
            : 8.0;

    return Card(
      margin: EdgeInsets.zero,
      elevation: active ? elevation : elevation / 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(borderRadius),
        side: BorderSide(
          color: active ? const Color(0xFF2E7D32) : Colors.transparent,
          width: active ? (size == TileSize.large ? 2.0 : 1.0) : 0,
        ),
      ),
      color: _getTileColor(),
      child: InkWell(
        borderRadius: BorderRadius.circular(borderRadius),
        onTap: active
            ? () {
                context
                    .read<ScoreCard>()
                    .registerScore(category, context.read<Dice>().values);
                context.read<Dice>().clear();
              }
            : null,
        child: Padding(
          padding: EdgeInsets.symmetric(
            vertical: verticalPadding,
            horizontal: horizontalPadding,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                category.name,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: fontSize,
                  fontWeight: FontWeight.bold,
                  color: active ? Colors.white : Colors.black87,
                  letterSpacing: size == TileSize.large ? 0.5 : 0.2,
                ),
              ),
              SizedBox(height: spacing),
              Text(
                score?.toString() ?? '-',
                style: TextStyle(
                  fontSize: scoreSize,
                  fontWeight: FontWeight.w800,
                  color: score != null
                      ? Colors.indigo.shade700
                      : Colors.grey.shade600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
