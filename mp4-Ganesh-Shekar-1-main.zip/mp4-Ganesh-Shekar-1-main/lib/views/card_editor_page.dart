import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/flashcard.dart';
import '../providers/flashcard_provider.dart';

class CardEditorPage extends StatefulWidget {
  final int deckId;
  final Flashcard? flashcard;

  const CardEditorPage({Key? key, required this.deckId, this.flashcard})
    : super(key: key);

  @override
  State<CardEditorPage> createState() => _CardEditorPageState();
}

class _CardEditorPageState extends State<CardEditorPage> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _questionController;
  late TextEditingController _answerController;
  bool _isNew = true;

  @override
  void initState() {
    super.initState();
    _isNew = widget.flashcard == null;
    _questionController = TextEditingController(
      text: widget.flashcard?.question ?? '',
    );
    _answerController = TextEditingController(
      text: widget.flashcard?.answer ?? '',
    );
  }

  @override
  void dispose() {
    _questionController.dispose();
    _answerController.dispose();
    super.dispose();
  }

  Future<void> _saveFlashcard() async {
    if (_formKey.currentState!.validate()) {
      final flashcardProvider = Provider.of<FlashcardProvider>(
        context,
        listen: false,
      );

      if (_isNew) {
        await flashcardProvider.addFlashcard(
          _questionController.text,
          _answerController.text,
        );
      } else {
        final updatedFlashcard = Flashcard(
          id: widget.flashcard!.id,
          question: _questionController.text,
          answer: _answerController.text,
          deckId: widget.deckId,
          createdAt: widget.flashcard!.createdAt,
        );
        await flashcardProvider.updateFlashcard(updatedFlashcard);
      }

      Navigator.pop(context);
    }
  }

  Future<void> _deleteFlashcard() async {
    if (!_isNew) {
      final flashcardProvider = Provider.of<FlashcardProvider>(
        context,
        listen: false,
      );
      await flashcardProvider.deleteFlashcard(widget.flashcard!.id!);
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_isNew ? 'Create Flashcard' : 'Edit Flashcard'),
        actions: [
          if (!_isNew)
            Padding(
              padding: const EdgeInsets.only(
                right: 20.0,
              ), // Add padding to the right
              child: IconButton(
                icon: const Icon(Icons.delete),
                onPressed: () {
                  showDialog(
                    context: context,
                    builder:
                        (context) => AlertDialog(
                          title: const Text('Delete Flashcard'),
                          content: const Text(
                            'Are you sure you want to delete this flashcard?',
                          ),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(context),
                              child: const Text('CANCEL'),
                            ),
                            TextButton(
                              onPressed: () {
                                Navigator.pop(context);
                                _deleteFlashcard();
                              },
                              child: const Text('DELETE'),
                            ),
                          ],
                        ),
                  );
                },
              ),
            ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextFormField(
                controller: _questionController,
                decoration: const InputDecoration(
                  labelText: 'Question',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a question';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16.0),
              TextFormField(
                controller: _answerController,
                decoration: const InputDecoration(
                  labelText: 'Answer',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter an answer';
                  }
                  return null;
                },
                maxLines: 3,
              ),
              const SizedBox(height: 16.0),
              ElevatedButton(
                onPressed: _saveFlashcard,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF26A69A),
                ),
                child: Text(
                  _isNew ? 'Create' : 'Save',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
