import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/deck_provider.dart';
import '../utils/json_loader.dart';
import 'card_list_page.dart';
import 'deck_editor_page.dart';

class DeckList extends StatefulWidget {
  const DeckList({Key? key}) : super(key: key);

  @override
  State<DeckList> createState() => _DeckListState();
}

class _DeckListState extends State<DeckList> {
  bool _isLoading = true;
  Map<int, int> _cardCounts = {}; // Map to store card counts

  @override
  void initState() {
    super.initState();
    _loadDecks();
  }

  Future<void> _loadDecks() async {
    final deckProvider = Provider.of<DeckProvider>(context, listen: false);
    await deckProvider.loadDecks();

    // Load card counts for each deck
    _cardCounts = {};
    for (var deck in deckProvider.decks) {
      if (deck.id != null) {
        _cardCounts[deck.id!] = await deckProvider.getFlashcardCount(deck.id!);
      }
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _loadFromJson() async {
    setState(() {
      _isLoading = true;
    });

    final jsonLoader = JsonLoader();
    await jsonLoader.loadFlashcardsFromJson();

    await _loadDecks();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Flashcard Decks'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(
              right: 20.0,
            ), // Add padding to the right
            child: IconButton(
              icon: const Icon(Icons.download),
              onPressed: _loadFromJson,
              tooltip: 'Load from JSON',
            ),
          ),
        ],
      ),
      body:
          _isLoading
              ? const Center(child: CircularProgressIndicator())
              : _buildDeckGrid(),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const DeckEditorPage()),
          ).then((_) => _loadDecks());
        },
        backgroundColor: const Color(0xFF26A69A),
        foregroundColor: Colors.white,
        child: const Icon(Icons.add),
        tooltip: 'Add Deck',
      ),
    );
  }

  Widget _buildDeckGrid() {
    return Consumer<DeckProvider>(
      builder: (context, deckProvider, child) {
        if (deckProvider.decks.isEmpty) {
          return const Center(
            child: Text('No decks available. Create one or load from JSON.'),
          );
        }

        return LayoutBuilder(
          builder: (context, constraints) {
            final crossAxisCount = constraints.maxWidth ~/ 180;
            return GridView.builder(
              padding: const EdgeInsets.all(16.0),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: crossAxisCount > 0 ? crossAxisCount : 1,
                crossAxisSpacing: 16.0,
                mainAxisSpacing: 16.0,
                childAspectRatio: 1.0,
              ),
              itemCount: deckProvider.decks.length,
              itemBuilder: (context, index) {
                final deck = deckProvider.decks[index];
                final cardCount =
                    _cardCounts[deck.id] ?? 0; // Get card count for this deck

                return Card(
                  color: const Color.fromARGB(255, 227, 165, 80),
                  child: InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => CardListPage(deck: deck),
                        ),
                      ).then((_) => _loadDecks());
                    },
                    child: Stack(
                      children: [
                        Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                deck.title,
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  fontSize: 18.0,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 8.0),
                              Text(
                                '$cardCount card${cardCount == 1 ? '' : 's'}',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 14.0,
                                  color: const Color.fromARGB(255, 0, 0, 0),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Positioned(
                          bottom: 0,
                          right: 0,
                          child: IconButton(
                            icon: const Icon(Icons.edit),
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder:
                                      (context) => DeckEditorPage(deck: deck),
                                ),
                              ).then((_) => _loadDecks());
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        );
      },
    );
  }
}
