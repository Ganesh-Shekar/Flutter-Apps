import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/deck.dart';
import '../models/flashcard.dart';
import '../providers/flashcard_provider.dart';

class QuizPage extends StatefulWidget {
  final Deck deck;

  const QuizPage({Key? key, required this.deck}) : super(key: key);

  @override
  State<QuizPage> createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  late List<Flashcard> _shuffledCards;
  int _currentIndex = 0;
  bool _showAnswer = false;
  Set<int> _viewedCards = {0}; // Start with first card already viewed
  Set<int> _peekedAnswers = {};
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadAndShuffleCards();
  }

  Future<void> _loadAndShuffleCards() async {
    final flashcardProvider =
        Provider.of<FlashcardProvider>(context, listen: false);
    await flashcardProvider.loadFlashcards(widget.deck.id!);
    setState(() {
      _shuffledCards = flashcardProvider.getShuffledFlashcards();
      _isLoading = false;
    });
  }

  void _nextCard() {
    setState(() {
      if (_currentIndex < _shuffledCards.length - 1) {
        _currentIndex++;
      } else {
        // If at the last card, wrap around to the first card
        _currentIndex = 0;
      }

      // Mark this card as viewed
      _viewedCards.add(_currentIndex);
      _showAnswer = false;
    });
  }

  void _previousCard() {
    setState(() {
      if (_currentIndex > 0) {
        _currentIndex--;
      } else {
        // If at the first card, go to the last card
        _currentIndex = _shuffledCards.length - 1;
      }

      // Mark this card as viewed
      _viewedCards.add(_currentIndex);
      _showAnswer = false;
    });
  }

  void _toggleAnswer() {
    setState(() {
      _showAnswer = !_showAnswer;
      if (_showAnswer) {
        _peekedAnswers.add(_currentIndex);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Scaffold(
        appBar: AppBar(title: Text('Quiz: ${widget.deck.title}')),
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    if (_shuffledCards.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: Text('Quiz: ${widget.deck.title}')),
        body: const Center(
          child: Text('No flashcards available in this deck.'),
        ),
      );
    }

    final currentCard = _shuffledCards[_currentIndex];

    return Scaffold(
      appBar: AppBar(
        title: Text('Quiz: ${widget.deck.title}'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              'Cards: ${_viewedCards.length}/${_shuffledCards.length} • Peeked: ${_peekedAnswers.length}/${_viewedCards.length}',
              style: const TextStyle(fontSize: 16.0),
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: GestureDetector(
                onTap: _toggleAnswer,
                child: Card(
                  color: _showAnswer
                      ? const Color.fromARGB(255, 91, 233, 96)
                      : const Color.fromARGB(255, 70, 161, 235),
                  elevation: 4.0,
                  child: Center(
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Text(
                        _showAnswer ? currentCard.answer : currentCard.question,
                        style: const TextStyle(fontSize: 24.0),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                IconButton(
                  icon: const Icon(Icons.arrow_back),
                  onPressed: _previousCard,
                  iconSize: 36.0,
                  tooltip: 'Previous Card',
                ),
                IconButton(
                  icon: const Icon(Icons.flip),
                  onPressed: _toggleAnswer,
                  iconSize: 36.0,
                  tooltip: 'Flip Card',
                ),
                IconButton(
                  icon: const Icon(Icons.arrow_forward),
                  onPressed: _nextCard,
                  iconSize: 36.0,
                  tooltip: 'Next Card',
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
