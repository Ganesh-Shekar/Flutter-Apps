import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/deck.dart';
import '../providers/deck_provider.dart';

class DeckEditorPage extends StatefulWidget {
  final Deck? deck;

  const DeckEditorPage({Key? key, this.deck}) : super(key: key);

  @override
  State<DeckEditorPage> createState() => _DeckEditorPageState();
}

class _DeckEditorPageState extends State<DeckEditorPage> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _titleController;
  bool _isNew = true;

  @override
  void initState() {
    super.initState();
    _isNew = widget.deck == null;
    _titleController = TextEditingController(text: widget.deck?.title ?? '');
  }

  @override
  void dispose() {
    _titleController.dispose();
    super.dispose();
  }

  Future<void> _saveDeck() async {
    if (_formKey.currentState!.validate()) {
      final deckProvider = Provider.of<DeckProvider>(context, listen: false);

      if (_isNew) {
        await deckProvider.addDeck(_titleController.text);
      } else {
        final updatedDeck = Deck(
          id: widget.deck!.id,
          title: _titleController.text,
        );
        await deckProvider.updateDeck(updatedDeck);
      }

      Navigator.pop(context);
    }
  }

  Future<void> _deleteDeck() async {
    if (!_isNew) {
      final deckProvider = Provider.of<DeckProvider>(context, listen: false);
      await deckProvider.deleteDeck(widget.deck!.id!);
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_isNew ? 'Create Deck' : 'Edit Deck'),
        actions: [
          if (!_isNew)
            Padding(
              padding: const EdgeInsets.only(
                right: 20.0,
              ), // Add padding to the right
              child: IconButton(
                icon: const Icon(Icons.delete),
                onPressed: () {
                  showDialog(
                    context: context,
                    builder:
                        (context) => AlertDialog(
                          title: const Text('Delete Deck'),
                          content: const Text(
                            'Are you sure you want to delete this deck? '
                            'All flashcards in this deck will also be deleted.',
                          ),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(context),
                              child: const Text('CANCEL'),
                            ),
                            TextButton(
                              onPressed: () {
                                Navigator.pop(context);
                                _deleteDeck();
                              },
                              child: const Text('DELETE'),
                            ),
                          ],
                        ),
                  );
                },
              ),
            ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextFormField(
                controller: _titleController,
                decoration: const InputDecoration(
                  labelText: 'Deck Title',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a title';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16.0),
              ElevatedButton(
                onPressed: _saveDeck,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF26A69A),
                ),
                child: Text(
                  _isNew ? 'Create' : 'Save',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
