import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/deck.dart';
import '../models/flashcard.dart';
import '../providers/flashcard_provider.dart';
import 'card_editor_page.dart';
import 'quiz_page.dart';

class CardListPage extends StatefulWidget {
  final Deck deck;

  const CardListPage({Key? key, required this.deck}) : super(key: key);

  @override
  State<CardListPage> createState() => _CardListPageState();
}

class _CardListPageState extends State<CardListPage> {
  bool _isLoading = true;
  bool _isAlphabetical = false;

  @override
  void initState() {
    super.initState();
    _loadFlashcards();
  }

  Future<void> _loadFlashcards() async {
    final flashcardProvider = Provider.of<FlashcardProvider>(
      context,
      listen: false,
    );
    await flashcardProvider.loadFlashcards(widget.deck.id!);
    setState(() {
      _isLoading = false;
    });
  }

  void _toggleSortOrder() {
    final flashcardProvider = Provider.of<FlashcardProvider>(
      context,
      listen: false,
    );
    setState(() {
      _isAlphabetical = !_isAlphabetical;
      if (_isAlphabetical) {
        flashcardProvider.sortByAlphabetical();
      } else {
        flashcardProvider.sortByCreationDate();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.deck.title),
        actions: [
          IconButton(
            icon: Icon(
              _isAlphabetical ? Icons.sort_by_alpha : Icons.access_time,
            ),
            onPressed: _toggleSortOrder,
            tooltip:
                _isAlphabetical
                    ? 'Sort by creation date'
                    : 'Sort alphabetically',
          ),
          Padding(
            padding: const EdgeInsets.only(
              right: 20.0,
            ), // Add padding to the right
            child: IconButton(
              icon: const Icon(Icons.quiz),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => QuizPage(deck: widget.deck),
                  ),
                );
              },
              tooltip: 'Start Quiz',
            ),
          ),
        ],
      ),
      body:
          _isLoading
              ? const Center(child: CircularProgressIndicator())
              : _buildCardGrid(),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => CardEditorPage(deckId: widget.deck.id!),
            ),
          ).then((_) => _loadFlashcards());
        },
        backgroundColor: const Color(0xFF26A69A),
        foregroundColor: Colors.white,
        child: const Icon(Icons.add),
        tooltip: 'Add Flashcard',
      ),
    );
  }

  Widget _buildCardGrid() {
    return Consumer<FlashcardProvider>(
      builder: (context, flashcardProvider, child) {
        if (flashcardProvider.flashcards.isEmpty) {
          return const Center(
            child: Text('No flashcards available. Create one to get started.'),
          );
        }

        return LayoutBuilder(
          builder: (context, constraints) {
            final crossAxisCount = constraints.maxWidth ~/ 150;
            return GridView.builder(
              padding: const EdgeInsets.all(16.0),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: crossAxisCount > 0 ? crossAxisCount : 1,
                crossAxisSpacing: 16.0,
                mainAxisSpacing: 16.0,
                childAspectRatio: 1.5,
              ),
              itemCount: flashcardProvider.flashcards.length,
              itemBuilder: (context, index) {
                final flashcard = flashcardProvider.flashcards[index];
                return _buildCardItem(flashcard);
              },
            );
          },
        );
      },
    );
  }

  Widget _buildCardItem(Flashcard flashcard) {
    return Card(
      color: const Color.fromARGB(255, 255, 124, 84),
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder:
                  (context) => CardEditorPage(
                    deckId: widget.deck.id!,
                    flashcard: flashcard,
                  ),
            ),
          ).then((_) => _loadFlashcards());
        },
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Center(
            child: Text(
              flashcard.question,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 16.0,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
