import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/deck_provider.dart';
import 'providers/flashcard_provider.dart';
import 'views/decklist.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => DeckProvider()),
        ChangeNotifierProvider(create: (_) => FlashcardProvider()),
      ],
      child: MaterialApp(
        title: 'Flashcards App',
        theme: ThemeData(
          primaryColor: const Color(0xFFFFB74D), //orange for app bar
          primarySwatch: Colors.amber,
          scaffoldBackgroundColor:
              const Color(0xFFFFF8E1), // Light amber background
          appBarTheme: const AppBarTheme(
            backgroundColor: Color(0xFFFFB74D), // Matching app bar color
            elevation: 1,
            foregroundColor: Colors.black, // Text color for app bar
          ),
          visualDensity: VisualDensity.adaptivePlatformDensity,
        ),
        home: const DeckList(),
      ),
    );
  }
}
