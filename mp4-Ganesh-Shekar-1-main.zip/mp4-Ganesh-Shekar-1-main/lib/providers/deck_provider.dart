import 'package:flutter/foundation.dart';
import '../models/deck.dart';
import '../utils/database_helper.dart';

class DeckProvider with ChangeNotifier {
  final DatabaseHelper _dbHelper = DatabaseHelper();
  List<Deck> _decks = [];
  
  List<Deck> get decks => _decks;

  Future<void> loadDecks() async {
    _decks = await _dbHelper.getDecks();
    notifyListeners();
  }

  Future<void> addDeck(String title) async {
    final deck = Deck(title: title);
    final id = await _dbHelper.insertDeck(deck);
    _decks.add(Deck(id: id, title: title));
    notifyListeners();
  }

  Future<void> updateDeck(Deck deck) async {
    await _dbHelper.updateDeck(deck);
    final index = _decks.indexWhere((d) => d.id == deck.id);
    if (index != -1) {
      _decks[index] = deck;
      notifyListeners();
    }
  }

  Future<void> deleteDeck(int id) async {
    await _dbHelper.deleteDeck(id);
    _decks.removeWhere((deck) => deck.id == id);
    notifyListeners();
  }

  Future<int> getFlashcardCount(int deckId) async {
    return await _dbHelper.getFlashcardCount(deckId);
  }
}
