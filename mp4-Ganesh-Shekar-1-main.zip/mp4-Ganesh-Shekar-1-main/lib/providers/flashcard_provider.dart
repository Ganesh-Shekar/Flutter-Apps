import 'package:flutter/foundation.dart';
import '../models/flashcard.dart';
import '../utils/database_helper.dart';

class FlashcardProvider with ChangeNotifier {
  final DatabaseHelper _dbHelper = DatabaseHelper();
  List<Flashcard> _flashcards = [];
  int _currentDeckId = -1;
  
  List<Flashcard> get flashcards => _flashcards;
  int get currentDeckId => _currentDeckId;

  Future<void> loadFlashcards(int deckId) async {
    _currentDeckId = deckId;
    _flashcards = await _dbHelper.getFlashcards(deckId);
    notifyListeners();
  }

  Future<void> addFlashcard(String question, String answer) async {
    if (_currentDeckId == -1) return;
    
    final flashcard = Flashcard(
      question: question,
      answer: answer,
      deckId: _currentDeckId,
    );
    
    final id = await _dbHelper.insertFlashcard(flashcard);
    _flashcards.add(Flashcard(
      id: id,
      question: question,
      answer: answer,
      deckId: _currentDeckId,
      createdAt: DateTime.now(),
    ));
    
    notifyListeners();
  }

  Future<void> updateFlashcard(Flashcard flashcard) async {
    await _dbHelper.updateFlashcard(flashcard);
    final index = _flashcards.indexWhere((f) => f.id == flashcard.id);
    if (index != -1) {
      _flashcards[index] = flashcard;
      notifyListeners();
    }
  }

  Future<void> deleteFlashcard(int id) async {
    await _dbHelper.deleteFlashcard(id);
    _flashcards.removeWhere((flashcard) => flashcard.id == id);
    notifyListeners();
  }

  void sortByAlphabetical() {
    _flashcards.sort((a, b) => a.question.compareTo(b.question));
    notifyListeners();
  }

  void sortByCreationDate() {
    _flashcards.sort((a, b) => a.createdAt.compareTo(b.createdAt));
    notifyListeners();
  }

  List<Flashcard> getShuffledFlashcards() {
    final shuffled = List<Flashcard>.from(_flashcards);
    shuffled.shuffle();
    return shuffled;
  }
}
