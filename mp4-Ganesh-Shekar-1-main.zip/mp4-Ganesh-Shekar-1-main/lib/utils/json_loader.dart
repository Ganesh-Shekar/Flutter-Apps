import 'dart:convert';
import 'package:flutter/services.dart';
import '../models/deck.dart';
import '../models/flashcard.dart';
import 'database_helper.dart';

class JsonLoader {
  final DatabaseHelper _dbHelper = DatabaseHelper();

  Future<void> loadFlashcardsFromJson() async {
    final String jsonString = await rootBundle.loadString('assets/flashcards.json');
    final List<dynamic> jsonData = json.decode(jsonString);
    
    for (var deckJson in jsonData) {
      // Create deck
      final deck = Deck.fromJson(deckJson);
      final deckId = await _dbHelper.insertDeck(deck);
      
      // Create flashcards for this deck
      final List<dynamic> flashcardsJson = deckJson['flashcards'];
      for (var cardJson in flashcardsJson) {
        final flashcard = Flashcard.fromJson(cardJson, deckId);
        await _dbHelper.insertFlashcard(flashcard);
      }
    }
  }
}
