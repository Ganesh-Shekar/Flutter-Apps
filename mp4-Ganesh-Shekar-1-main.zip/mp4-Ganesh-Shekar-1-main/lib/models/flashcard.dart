class Flashcard {
  final int? id;
  String question;
  String answer;
  final int deckId;
  final DateTime createdAt;

  Flashcard({
    this.id,
    required this.question,
    required this.answer,
    required this.deckId,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'question': question,
      'answer': answer,
      'deck_id': deckId,
      'created_at': createdAt.toIso8601String(),
    };
  }

  factory Flashcard.fromMap(Map<String, dynamic> map) {
    return Flashcard(
      id: map['id'],
      question: map['question'],
      answer: map['answer'],
      deckId: map['deck_id'],
      createdAt: DateTime.parse(map['created_at']),
    );
  }

  factory Flashcard.fromJson(Map<String, dynamic> json, int deckId) {
    return Flashcard(
      question: json['question'],
      answer: json['answer'],
      deckId: deckId,
    );
  }
}
