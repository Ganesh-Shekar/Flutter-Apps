# MP Report

## Team

- Name(s): Ganesh Prasad Chandra Shekar
- AID(s): A20557831

## Self-Evaluation Checklist

Tick the boxes (i.e., fill them with 'X's) that apply to your submission:

- [x] The app builds without error
- [x] I tested the app in at least one of the following platforms (check all that apply):
  - [x] iOS simulator / MacOS
  - [ ] Android emulator
- [x] Decks can be created, edited, and deleted
- [x] Cards can be created, edited, sorted, and deleted
- [x] Quizzes work correctly
- [x] Decks and Cards can be loaded from the JSON file
- [x] Decks and Cards are saved/loaded correctly from/to a SQLite database
- [x] The UI is responsive to changes in screen size

## Summary and Reflection

Working on this flashcard application has been a rewarding experience that challenged me to apply various Flutter concepts in a practical context. I built a complete system allowing users to create and manage decks of flashcards, with features including deck creation/editing, card management, and quiz functionality. The application uses SQLite for data persistence, Provider for state management, and follows a modular architecture separating models, views, and business logic. I implemented all the required screens: deck list, deck editor, card list, card editor, and quiz functionality. The UI is responsive and user-friendly, with appropriate loading indicators during asynchronous operations and intuitive navigation between screens.

The most challenging aspects of this project were implementing proper database operations with SQLite while keeping the UI responsive, and ensuring state changes propagated correctly throughout the application. I learned a lot about the Provider pattern and how it simplifies state management compared to other approaches we've studied. The modular architecture I implemented made the code more maintainable and easier to debug. I particularly enjoyed implementing the deck editor page, where I had to carefully consider the user experience for both creating new decks and editing existing ones. This project has significantly improved my understanding of Flutter development, especially regarding asynchronous programming and database integration skills.
