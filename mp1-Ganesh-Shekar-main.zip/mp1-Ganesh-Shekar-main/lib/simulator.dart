import 'package:yaml/yaml.dart';
import 'processes.dart';

/// Statistics for a single process.
class ProcessStats {
  int eventsGenerated = 0;
  int totalWaitTime = 0;

  double get averageWaitTime =>
      eventsGenerated > 0 ? totalWaitTime / eventsGenerated : 0.0;
}

/// Queueing system simulator.
class Simulator {
  final bool verbose;
  final Map<String, ProcessStats> stats = {};
  final List<Event> allEvents = [];
  int currentTime = 0;

  Simulator(YamlMap yamlData, {this.verbose = false}) {
    // Create processes from YAML data
    for (final name in yamlData.keys) {
      final fields = yamlData[name];
      final process = _createProcess(name, fields);
      if (process != null) {
        allEvents.addAll(process.generateEvents());
        stats[name] = ProcessStats();
      }
    }

    // Sort events by arrival time
    allEvents.sort((a, b) => a.arrivalTime.compareTo(b.arrivalTime));
  }

  /// Creates a process based on its type specified in the YAML fields.
  ///
  /// Supports three process types:
  /// - 'singleton': Returns a SingletonProcess with specified duration and arrival time.
  /// - 'periodic': Returns a PeriodicProcess with specified duration, interarrival time,
  ///   first arrival time, and number of repetitions.
  /// - 'stochastic': Returns a StochasticProcess with mean duration, mean interarrival time,
  ///   first arrival time, and end time.
  ///
  /// If the process type is unknown, prints an error message and returns null.

  Process? _createProcess(String name, YamlMap fields) {
    switch (fields['type']) {
      case 'singleton':
        return SingletonProcess(name, fields['duration'], fields['arrival']);
      case 'periodic':
        return PeriodicProcess(
            name,
            fields['duration'],
            fields['interarrival-time'],
            fields['first-arrival'],
            fields['num-repetitions']);
      case 'stochastic':
        return StochasticProcess(
            name,
            fields['mean-duration'].toDouble(),
            fields['mean-interarrival-time'].toDouble(),
            fields['first-arrival'],
            fields['end']);
      default:
        print('Unknown process type: ${fields['type']}');
        return null;
    }
  }

  /// Runs the simulation. Iterates through all events, updating each event's
  /// start time and wait time based on the current time and the previous
  /// event's duration. Prints a trace message if verbose is true. Updates
  /// process statistics with the number of events generated and total wait
  /// time. Moves the current time forward by each event's duration.
  void run() {
    Event? currentEvent;

    for (final event in allEvents) {
      if (currentEvent != null && event.arrivalTime < currentTime) {
        // Event arrives while another is being processed
        event.waitTime = currentTime - event.arrivalTime;
      } else {
        // Event arrives to empty queue
        currentTime = event.arrivalTime;
        event.waitTime = 0;
      }

      event.startTime = currentTime;
      if (verbose) {
        print(
            't=$currentTime: ${event.processName}, duration ${event.duration} '
            'started (arrived @ ${event.arrivalTime}, '
            '${event.waitTime == 0 ? "no wait" : "waited ${event.waitTime}"})');
      }

      // Update stats
      stats[event.processName]!.eventsGenerated++;
      stats[event.processName]!.totalWaitTime += event.waitTime!;

      // Move time forward by event duration
      currentTime += event.duration;
      currentEvent = event;
    }
  }

  /// Prints a summary report of the simulation run, including
  ///
  /// - a breakdown of statistics for each process (events generated, total wait
  ///   time, and average wait time)
  /// - a summary of all events, including the total number of events, the total
  ///   wait time, and the average wait time across all processes
  void printReport() {
    if (verbose) {
      print(
          '\n--------------------------------------------------------------\n');
    }

    print('# Per-process statistics\n');
    for (final name in stats.keys) {
      final processStats = stats[name]!;
      print('$name:');
      print('  Events generated:  ${processStats.eventsGenerated}');
      print('  Total wait time:   ${processStats.totalWaitTime}');
      print(
          '  Average wait time: ${processStats.averageWaitTime.toStringAsFixed(2)}\n');
    }

    print('--------------------------------------------------------------\n');
    print('# Summary statistics\n');

    final totalEvents =
        stats.values.map((s) => s.eventsGenerated).reduce((a, b) => a + b);
    final totalWaitTime =
        stats.values.map((s) => s.totalWaitTime).reduce((a, b) => a + b);
    final averageWaitTime = totalWaitTime / totalEvents;

    print('Total num events:  $totalEvents');
    print('Total wait time:   $totalWaitTime.0');
    print('Average wait time: ${averageWaitTime.toStringAsFixed(3)}');
  }
}
