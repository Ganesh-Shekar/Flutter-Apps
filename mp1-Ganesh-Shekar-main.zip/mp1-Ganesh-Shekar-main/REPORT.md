# MP Report

## Team

- Name(s): Ganesh Prasad Chandra Shekar
- AID(s): A20557831

## Self-Evaluation Checklist

Tick the boxes (i.e., fill them with 'X's) that apply to your submission:

- [x] The simulator builds without error
- [x] The simulator runs on at least one configuration file without crashing
- [x] Verbose output (via the `-v` flag) is implemented
- [x] I used the provided starter code
- The simulator runs correctly (to the best of my knowledge) on the provided configuration file(s):
  - [x] conf/sim1.yaml
  - [x] conf/sim2.yaml
  - [x] conf/sim3.yaml
  - [x] conf/sim4.yaml
  - [x] conf/sim5.yaml

## Summary and Reflection

This machine problem focused on implementing a queueing system simulator that handles multiple process types and generates events using stochastic processes. The implementation centered on using a priority queue for event management, with separate classes for singleton, periodic, and stochastic processes, all inheriting from a common Process base class to maintain a unified interface. Key technical challenges included correctly generating random interarrival and service times using exponential distributions through the ExpDistribution class, ensuring proper event ordering when multiple events arrived simultaneously, and implementing accurate wait time tracking. The project required careful attention to various aspects such as preventing events from being generated beyond the simulation end time, maintaining minimum values for interarrival and service times, and implementing comprehensive logging for debugging.

Throughout the development process, several challenges emerged, including initial mistakes in scaling exponential distribution results and debugging YAML parsing issues that could have been prevented with better input validation. Despite these obstacles, the project provided valuable insights into queue-based systems and their behaviors under different process configurations. The experience enhanced understanding of practical applications of exponential distributions in queueing theory and highlighted the importance of thorough input validation and logging from the project's onset. Looking back, while the implementation of stochastic processes and event management proved challenging, the project successfully deepened understanding of real-world systems that handle requests and resources, making it a worthwhile learning experience in designing event-driven simulations.
