# MP Report

## Student information

- Name: Ganesh Prasad Chandra Shekar
- AID: A20557831

## Self-Evaluation Checklist

Tick the boxes (i.e., fill them with 'X's) that apply to your submission:

- [x] The app builds without error
- [x] I tested the app in at least one of the following platforms (check all
      that apply):
  - [x] iOS simulator / MacOS
  - [ ] Android emulator
- [x] Users can register and log in to the server via the app
- [x] Session management works correctly; i.e., the user stays logged in after
      closing and reopening the app, and token expiration necessitates re-login
- [x] The game list displays required information accurately (for both active
      and completed games), and can be manually refreshed
- [x] A game can be started correctly (by placing ships, and sending an
      appropriate request to the server)
- [x] The game board is responsive to changes in screen size
- [x] Games can be started with human and all supported AI opponents
- [x] Gameplay works correctly (including ship placement, attacking, and game
      completion)

## Summary and Reflection

For this implementation, I focused on creating a user-friendly Battleship game application. One of the key decisions was implementing a clean MVVM architecture to separate concerns between the UI, business logic, and data layers. I made sure that the game is responsive to different screen sizes. For the backend communication, I implemented proper error handling and token-based authentication. The game board implementation was particularly challenging, requiring careful consideration of state management to handle both ship placement and attack phases. I also ensured smooth gameplay even with network interruptions. The built app was tested on IOS Simulator.

This project was an excellent opportunity to work with modern iOS development practices and networking concepts. I particularly enjoyed implementing the game logic and creating an intuitive user interface. The most challenging aspects were handling the real-time game state updates and ensuring proper session management across app restarts. The project gave me valuable insights into building full-stack mobile applications and handling complex game state management.
