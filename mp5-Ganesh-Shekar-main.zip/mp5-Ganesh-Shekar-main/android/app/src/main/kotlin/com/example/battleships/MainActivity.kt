package com.example.battleships

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
