import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/auth_model.dart';

class LoginView extends StatefulWidget {
  const LoginView({super.key});

  @override
  State<LoginView> createState() => _LoginViewState();
}

class _LoginViewState extends State<LoginView> {
  final _formKey = GlobalKey<FormState>();
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _isRegistering = false;

  @override
  void dispose() {
    _usernameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void _submitForm() async {
    if (_formKey.currentState!.validate()) {
      final authModel = Provider.of<AuthModel>(context, listen: false);
      bool success;

      if (_isRegistering) {
        success = await authModel.register(
          _usernameController.text.trim(),
          _passwordController.text,
        );
      } else {
        success = await authModel.login(
          _usernameController.text.trim(),
          _passwordController.text,
        );
      }

      if (success && mounted) {
        Navigator.pushReplacementNamed(context, '/games');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final authModel = Provider.of<AuthModel>(context);

    return Scaffold(
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final maxWidth = constraints.maxWidth;
            final isWideScreen = maxWidth > 600;
            final contentWidth = isWideScreen ? 400.0 : maxWidth;
            final horizontalPadding =
                isWideScreen ? (maxWidth - contentWidth) / 2 : 24.0;

            return Center(
              child: SingleChildScrollView(
                child: Padding(
                  padding: EdgeInsets.symmetric(
                    horizontal: horizontalPadding,
                    vertical: 24.0,
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Logo/Title
                      Icon(
                        Icons.directions_boat,
                        size: isWideScreen ? 100 : 80,
                        color: const Color(0xFF1A5276),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'BATTLESHIPS',
                        style:
                            Theme.of(context).textTheme.displayLarge?.copyWith(
                                  fontSize: isWideScreen ? 32 : 28,
                                ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        _isRegistering
                            ? 'Create an account'
                            : 'Sign in to play',
                        style: Theme.of(context).textTheme.bodyLarge,
                      ),
                      const SizedBox(height: 40),

                      // Form
                      Form(
                        key: _formKey,
                        child: Column(
                          children: [
                            // Username field
                            TextFormField(
                              controller: _usernameController,
                              decoration: InputDecoration(
                                labelText: 'Username',
                                prefixIcon: const Icon(Icons.person),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                              validator: (value) {
                                if (value == null || value.trim().length < 3) {
                                  return 'Username must be at least 3 characters';
                                }
                                if (value.contains(' ')) {
                                  return 'Username cannot contain spaces';
                                }
                                return null;
                              },
                            ),
                            const SizedBox(height: 16),

                            // Password field
                            TextFormField(
                              controller: _passwordController,
                              obscureText: true,
                              decoration: InputDecoration(
                                labelText: 'Password',
                                prefixIcon: const Icon(Icons.lock),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                              validator: (value) {
                                if (value == null || value.trim().length < 3) {
                                  return 'Password must be at least 3 characters';
                                }
                                if (value.contains(' ')) {
                                  return 'Password cannot contain spaces';
                                }
                                return null;
                              },
                            ),
                            const SizedBox(height: 24),

                            // Error message
                            if (authModel.errorMessage != null)
                              Container(
                                padding: const EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  color: Colors.red.shade100,
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(
                                  authModel.errorMessage!,
                                  style: TextStyle(color: Colors.red.shade900),
                                  textAlign: TextAlign.center,
                                ),
                              ),
                            const SizedBox(height: 24),

                            // Submit button
                            SizedBox(
                              width: double.infinity,
                              child: ElevatedButton(
                                onPressed:
                                    authModel.isLoading ? null : _submitForm,
                                child: Padding(
                                  padding: EdgeInsets.symmetric(
                                    vertical: isWideScreen ? 16 : 12,
                                  ),
                                  child: authModel.isLoading
                                      ? const SizedBox(
                                          height: 20,
                                          width: 20,
                                          child: CircularProgressIndicator(
                                            color: Colors.white,
                                            strokeWidth: 2,
                                          ),
                                        )
                                      : Text(
                                          _isRegistering ? 'REGISTER' : 'LOGIN',
                                          style: TextStyle(
                                            fontSize: isWideScreen ? 18 : 16,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                ),
                              ),
                            ),
                            const SizedBox(height: 16),

                            // Toggle button
                            TextButton(
                              onPressed: () {
                                setState(() {
                                  _isRegistering = !_isRegistering;
                                });
                              },
                              child: Text(
                                _isRegistering
                                    ? 'Already have an account? Login'
                                    : 'No account? Register now',
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
