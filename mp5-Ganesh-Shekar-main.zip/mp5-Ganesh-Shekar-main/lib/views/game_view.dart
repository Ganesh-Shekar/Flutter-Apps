import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/auth_model.dart';
import '../models/game_model.dart';
import '../utils/board_utils.dart';

class GameView extends StatefulWidget {
  const GameView({super.key});

  @override
  State<GameView> createState() => _GameViewState();
}

class _GameViewState extends State<GameView> {
  int? _gameId;
  String? _selectedPosition;
  bool _isPlayingShot = false;
  bool _isRefreshing = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final args =
        ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
    if (args != null && args.containsKey('gameId')) {
      final newGameId = args['gameId'] as int;
      if (_gameId != newGameId) {
        _gameId = newGameId;
        WidgetsBinding.instance.addPostFrameCallback((_) {
          _loadGameDetails();
        });
      }
    }
  }

  Future<void> _loadGameDetails() async {
    if (_gameId == null) return;

    if (!_isRefreshing) {
      setState(() {
        _isRefreshing = true;
      });
    }

    final authModel = Provider.of<AuthModel>(context, listen: false);
    final gameModel = Provider.of<GameModel>(context, listen: false);

    if (authModel.token != null) {
      await gameModel.fetchGameDetails(authModel.token!, _gameId!);
    }

    if (mounted && _isRefreshing) {
      setState(() {
        _isRefreshing = false;
        _selectedPosition = null;
      });
    }
  }

  void _selectPosition(String position) {
    final gameModel = Provider.of<GameModel>(context, listen: false);
    final game = gameModel.currentGame;

    if (game == null || !game.isYourTurn()) return;

    // Check if the position was already played (hit or miss)
    if ((game.shots?.contains(position) ?? false) ||
        (game.sunk?.contains(position) ?? false)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('You already played at this position'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    setState(() {
      _selectedPosition = position;
    });
  }

  Future<void> _playShot() async {
    if (_gameId == null || _selectedPosition == null) return;

    setState(() {
      _isPlayingShot = true;
    });

    final authModel = Provider.of<AuthModel>(context, listen: false);
    final gameModel = Provider.of<GameModel>(context, listen: false);

    if (authModel.token != null) {
      final result = await gameModel.playShot(
        authModel.token!,
        _gameId!,
        _selectedPosition!,
      );

      if (result != null && mounted) {
        String message;
        if (result['won'] == true) {
          message = 'You won the game! 🎉';
        } else if (result['sunk_ship'] == true) {
          message = 'You sunk an enemy ship! 💥';
        } else {
          message = 'Miss! 💦';
        }

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(message)),
        );

        // Refresh the game to see the result
        await _loadGameDetails();

        // For AI games, we need to refresh again to see AI's move
        if (gameModel.currentGame?.player2.contains('AI') == true) {
          await Future.delayed(const Duration(milliseconds: 1000));
          await _loadGameDetails();
        }
      }
    }

    if (mounted) {
      setState(() {
        _isPlayingShot = false;
        _selectedPosition = null;
      });
    }
  }

  Widget _buildGameStatus(Game game) {
    final status = game.getStatusText();
    final color = game.getStatusColor();

    IconData icon;
    if (game.status == 0) {
      icon = Icons.hourglass_bottom;
    } else if ((game.status == 1 && game.position == 1) ||
        (game.status == 2 && game.position == 2)) {
      icon = Icons.emoji_events;
    } else if ((game.status == 1 && game.position == 2) ||
        (game.status == 2 && game.position == 1)) {
      icon = Icons.close;
    } else if (game.status == 3) {
      if (game.turn == game.position) {
        icon = Icons.play_arrow;
      } else {
        icon = Icons.hourglass_top;
      }
    } else {
      icon = Icons.error;
    }

    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color),
          const SizedBox(width: 8),
          Text(
            status,
            style: TextStyle(
              color: color,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGameInfo(Game game) {
    return Card(
      margin: const EdgeInsets.all(16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Game #${game.id}',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                _buildGameStatus(game),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Player 1',
                        style: TextStyle(
                          color: Colors.grey.shade600,
                          fontSize: 12,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        game.player1,
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: game.position == 1 ? Colors.blue : null,
                        ),
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.compare_arrows),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        'Player 2',
                        style: TextStyle(
                          color: Colors.grey.shade600,
                          fontSize: 12,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        game.player2,
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: game.position == 2 ? Colors.blue : null,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGameBoard(Game game) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final boardSize = 5;
        final availableWidth = constraints.maxWidth;
        final cellSize = (availableWidth / (boardSize + 1)).clamp(30.0, 60.0);
        final headerSize = cellSize;
        final rows = List.generate(
            boardSize, (i) => String.fromCharCode('A'.codeUnitAt(0) + i));
        final cols = List.generate(boardSize, (i) => (i + 1).toString());

        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Game status indicator
            Container(
              margin: const EdgeInsets.symmetric(vertical: 16),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: game.isYourTurn()
                    ? Colors.blue.shade50
                    : Colors.grey.shade100,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: game.isYourTurn() ? Colors.blue : Colors.grey,
                  width: 2,
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    game.isYourTurn() ? Icons.play_arrow : Icons.hourglass_top,
                    color: game.isYourTurn() ? Colors.blue : Colors.grey,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    game.isYourTurn() ? 'Your Turn' : 'Opponent\'s Turn',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: game.isYourTurn() ? Colors.blue : Colors.grey,
                    ),
                  ),
                ],
              ),
            ),

            // Game board grid
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Container(
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey.shade300),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Column headers
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SizedBox(
                          width: headerSize,
                          height: headerSize,
                          child: const Center(child: Text('')),
                        ),
                        ...cols.map((col) => SizedBox(
                              width: cellSize,
                              height: headerSize,
                              child: Center(
                                child: Text(
                                  col,
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Colors.grey.shade600,
                                  ),
                                ),
                              ),
                            )),
                      ],
                    ),
                    // Board rows
                    ...rows.map((row) => Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            SizedBox(
                              width: headerSize,
                              height: cellSize,
                              child: Center(
                                child: Text(
                                  row,
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Colors.grey.shade600,
                                  ),
                                ),
                              ),
                            ),
                            ...cols.map((col) {
                              final position = '$row$col';
                              final hasShip =
                                  game.ships?.contains(position) ?? false;
                              final isWreck =
                                  game.wrecks?.contains(position) ?? false;
                              final isYourMiss =
                                  game.shots?.contains(position) ?? false;
                              final isYourHit =
                                  game.sunk?.contains(position) ?? false;
                              final isSelected = position == _selectedPosition;
                              final isPartOfSunkShip = game.sunkShips?.any(
                                      (sunkShip) =>
                                          (sunkShip['positions'] as List)
                                              .contains(position)) ??
                                  false;

                              Color cellColor = Colors.white;
                              List<Widget> cellIcons = [];

                              // Show wreck icon if cell is wrecked
                              if (isWreck) {
                                cellColor = Colors.red.shade100;
                                cellIcons.add(Icon(Icons.local_fire_department,
                                    size: cellSize * 0.4, color: Colors.red));
                              }

                              // Show ship icon if cell has your ship and it's your turn or game is not active
                              if (hasShip &&
                                  (game.isYourTurn() || game.status != 3)) {
                                cellColor = cellColor == Colors.white
                                    ? Colors.blue.shade100
                                    : cellColor;
                                cellIcons.add(Icon(Icons.directions_boat,
                                    size: cellSize * 0.4, color: Colors.blue));
                              }

                              // Show hit icon if cell is part of sunk ship or your hit
                              if (isPartOfSunkShip || isYourHit) {
                                cellColor = cellColor == Colors.white
                                    ? Colors.green.shade50
                                    : cellColor;
                                cellIcons.add(Icon(Icons.bolt,
                                    size: cellSize * 0.4,
                                    color: Colors.green.shade700));
                              }
                              // Show miss icon if it's your miss
                              else if (isYourMiss) {
                                cellColor = cellColor == Colors.white
                                    ? Colors.blue.shade50
                                    : cellColor;
                                cellIcons.add(Icon(Icons.water_drop,
                                    size: cellSize * 0.4,
                                    color: Colors.blue.shade700));
                              }

                              // Show selection icon if cell is selected
                              if (isSelected) {
                                cellColor = Colors.amber.shade100;
                                cellIcons.add(Icon(Icons.gps_fixed,
                                    size: cellSize * 0.4, color: Colors.amber));
                              }

                              return SizedBox(
                                width: cellSize,
                                height: cellSize,
                                child: InkWell(
                                  onTap: game.isYourTurn() &&
                                          !isYourHit &&
                                          !isYourMiss &&
                                          !isPartOfSunkShip
                                      ? () => _selectPosition(position)
                                      : null,
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: cellColor,
                                      border: Border.all(
                                        color: isSelected
                                            ? Colors.amber
                                            : Colors.grey.shade300,
                                        width: isSelected ? 2 : 1,
                                      ),
                                    ),
                                    child: cellIcons.isNotEmpty
                                        ? Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            mainAxisSize: MainAxisSize.min,
                                            children: cellIcons,
                                          )
                                        : null,
                                  ),
                                ),
                              );
                            }),
                          ],
                        )),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 16),

            // Fire button
            if (game.isYourTurn())
              Center(
                child: ElevatedButton.icon(
                  onPressed: _selectedPosition != null && !_isPlayingShot
                      ? _playShot
                      : null,
                  icon: const Icon(Icons.local_fire_department),
                  label: const Text('FIRE!'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 24, vertical: 12),
                  ),
                ),
              ),

            const SizedBox(height: 16),

            // Legend
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Wrap(
                alignment: WrapAlignment.center,
                spacing: 16,
                runSpacing: 8,
                children: [
                  _buildLegendItem(Icons.directions_boat, Colors.blue, 'Ship'),
                  _buildLegendItem(Icons.bolt, Colors.green.shade700, 'Hit'),
                  _buildLegendItem(
                      Icons.water_drop, Colors.blue.shade700, 'Miss'),
                  _buildLegendItem(
                      Icons.local_fire_department, Colors.red, 'Opp Hit'),
                  if (game.isYourTurn())
                    _buildLegendItem(Icons.gps_fixed, Colors.amber, 'Selected'),
                ],
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildLegendItem(IconData icon, Color color, String label) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 16, color: color),
        const SizedBox(width: 4),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey.shade700,
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final gameModel = Provider.of<GameModel>(context);
    final game = gameModel.currentGame;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Battleships Game'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _isRefreshing ? null : _loadGameDetails,
            tooltip: 'Refresh game',
          ),
        ],
      ),
      body: _isRefreshing
          ? const Center(child: CircularProgressIndicator())
          : game == null
              ? const Center(child: Text('Game not found'))
              : SafeArea(
                  child: LayoutBuilder(
                    builder: (context, constraints) {
                      final maxWidth = constraints.maxWidth;
                      final padding = maxWidth > 600 ? 32.0 : 16.0;
                      final contentWidth = maxWidth - (padding * 2);

                      return SingleChildScrollView(
                        child: Center(
                          child: Container(
                            constraints: const BoxConstraints(maxWidth: 600),
                            padding: EdgeInsets.symmetric(horizontal: padding),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                _buildGameInfo(game),
                                const SizedBox(height: 8),
                                _buildGameBoard(game),
                                const SizedBox(height: 24),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
    );
  }
}
