import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/auth_model.dart';
import '../models/game_model.dart';

class GameListView extends StatefulWidget {
  const GameListView({super.key});

  @override
  State<GameListView> createState() => _GameListViewState();
}

class _GameListViewState extends State<GameListView> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final GlobalKey<RefreshIndicatorState> _refreshIndicatorKey = GlobalKey<RefreshIndicatorState>();
  
  @override
  void initState() {
    super.initState();
    // Load games when the view is initialized
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _refreshGames();
      _validateToken();
    });
  }

  Future<void> _validateToken() async {
    final authModel = Provider.of<AuthModel>(context, listen: false);
    bool isValid = await authModel.validateToken();
    if (!isValid && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Session expired. Please log in again.')),
      );
      Navigator.pushReplacementNamed(context, '/');
    }
  }

  Future<void> _refreshGames() async {
    final authModel = Provider.of<AuthModel>(context, listen: false);
    final gameModel = Provider.of<GameModel>(context, listen: false);
    
    if (authModel.token != null) {
      await gameModel.fetchGames(authModel.token!);
    }
  }

  Future<void> _deleteGame(int gameId) async {
    final authModel = Provider.of<AuthModel>(context, listen: false);
    final gameModel = Provider.of<GameModel>(context, listen: false);
    
    if (authModel.token != null) {
      bool success = await gameModel.deleteGame(authModel.token!, gameId);
      if (success && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Game forfeited successfully')),
        );
      }
    }
  }

  void _showAISelectionDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Select AI Opponent'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.casino),
              title: const Text('Random AI'),
              subtitle: const Text('Makes random moves'),
              onTap: () {
                Navigator.of(context).pop();
                _startAIGame('random');
              },
            ),
            ListTile(
              leading: const Icon(Icons.psychology),
              title: const Text('Perfect AI'),
              subtitle: const Text('Makes perfect moves'),
              onTap: () {
                Navigator.of(context).pop();
                _startAIGame('perfect');
              },
            ),
            ListTile(
              leading: const Icon(Icons.anchor),
              title: const Text('One Ship AI'),
              subtitle: const Text('Has only one ship at A1'),
              onTap: () {
                Navigator.of(context).pop();
                _startAIGame('oneship');
              },
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('CANCEL'),
          ),
        ],
      ),
    );
  }

  void _startAIGame(String aiType) {
    Navigator.pushNamed(
      context, 
      '/place_ships',
      arguments: {'ai': aiType},
    ).then((_) => _refreshGames());
  }

  void _openGameDetails(Game game) {
    Navigator.pushNamed(
      context,
      '/game',
      arguments: {'gameId': game.id},
    ).then((_) => _refreshGames());
  }

  @override
  Widget build(BuildContext context) {
    final authModel = Provider.of<AuthModel>(context);
    final gameModel = Provider.of<GameModel>(context);

    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: const Text('Battleships'),
        leading: IconButton(
          icon: const Icon(Icons.menu),
          onPressed: () => _scaffoldKey.currentState?.openDrawer(),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => _refreshIndicatorKey.currentState?.show(),
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primary,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(
                    Icons.directions_boat,
                    size: 60,
                    color: Colors.white,
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'Battleships',
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                          color: Colors.white,
                        ),
                  ),
                  Text(
                    'Logged in as ${authModel.username}',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Colors.white70,
                        ),
                  ),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(Icons.group),
              title: const Text('New Game (vs Human)'),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, '/place_ships')
                    .then((_) => _refreshGames());
              },
            ),
            ListTile(
              leading: const Icon(Icons.computer),
              title: const Text('New Game (vs AI)'),
              onTap: () {
                Navigator.pop(context);
                _showAISelectionDialog();
              },
            ),
            ListTile(
              leading: Icon(
                gameModel.showCompletedGames
                    ? Icons.timer
                    : Icons.checklist_rtl,
              ),
              title: Text(
                gameModel.showCompletedGames
                    ? 'Show Active Games'
                    : 'Show Completed Games',
              ),
              onTap: () {
                gameModel.toggleShowCompletedGames();
                Navigator.pop(context);
              },
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text('Log Out'),
              onTap: () {
                authModel.logout();
                Navigator.pushReplacementNamed(context, '/');
              },
            ),
          ],
        ),
      ),
      body: RefreshIndicator(
        key: _refreshIndicatorKey,
        onRefresh: _refreshGames,
        child: gameModel.isLoading
            ? const Center(child: CircularProgressIndicator())
            : gameModel.games.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(
                          Icons.hourglass_empty,
                          size: 80,
                          color: Colors.grey,
                        ),
                        const SizedBox(height: 16),
                        Text(
                          gameModel.showCompletedGames
                              ? 'No completed games'
                              : 'No active games',
                          style: Theme.of(context).textTheme.headlineSmall,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          gameModel.showCompletedGames
                              ? 'Games you complete will appear here'
                              : 'Start a new game to play',
                          style: Theme.of(context).textTheme.bodyLarge,
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.all(8),
                    itemCount: gameModel.games.length,
                    itemBuilder: (context, index) {
                      final game = gameModel.games[index];
                      return Card(
                        margin: const EdgeInsets.symmetric(
                          vertical: 8,
                          horizontal: 4,
                        ),
                        child: ListTile(
                          contentPadding: const EdgeInsets.symmetric(
                            vertical: 8,
                            horizontal: 16,
                          ),
                          leading: CircleAvatar(
                            backgroundColor: game.getStatusColor(),
                            child: Icon(
                              _getStatusIcon(game),
                              color: Colors.white,
                            ),
                          ),
                          title: Text(
                            'Game #${game.id}',
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const SizedBox(height: 4),
                              Text(
                                '${game.player1} vs ${game.player2}',
                              ),
                              const SizedBox(height: 4),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 8,
                                  vertical: 2,
                                ),
                                decoration: BoxDecoration(
                                  color: game.getStatusColor().withOpacity(0.2),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Text(
                                  game.getStatusText(),
                                  style: TextStyle(
                                    color: game.getStatusColor(),
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          trailing: game.isActive()
                              ? IconButton(
                                  icon: const Icon(Icons.delete, color: Colors.red),
                                  onPressed: () => _deleteGame(game.id),
                                )
                              : null,
                          onTap: () => _openGameDetails(game),
                        ),
                      );
                    },
                  ),
      ),
      floatingActionButton: !gameModel.showCompletedGames
          ? FloatingActionButton(
              onPressed: () => Navigator.pushNamed(context, '/place_ships')
                  .then((_) => _refreshGames()),
              child: const Icon(Icons.add),
            )
          : null,
    );
  }

  IconData _getStatusIcon(Game game) {
    if (game.status == 0) {
      return Icons.hourglass_bottom;
    } else if ((game.status == 1 && game.position == 1) ||
        (game.status == 2 && game.position == 2)) {
      return Icons.emoji_events;
    } else if ((game.status == 1 && game.position == 2) ||
        (game.status == 2 && game.position == 1)) {
      return Icons.close;
    } else if (game.status == 3) {
      if (game.turn == game.position) {
        return Icons.play_arrow;
      } else {
        return Icons.hourglass_top;
      }
    }
    return Icons.error;
  }
}