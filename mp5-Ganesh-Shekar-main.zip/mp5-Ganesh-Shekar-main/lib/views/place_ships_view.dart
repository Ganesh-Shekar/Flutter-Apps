import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/auth_model.dart';
import '../models/game_model.dart';
import '../utils/board_utils.dart';

class PlaceShipsView extends StatefulWidget {
  const PlaceShipsView({super.key});

  @override
  State<PlaceShipsView> createState() => _PlaceShipsViewState();
}

class _PlaceShipsViewState extends State<PlaceShipsView> {
  final List<String> _selectedPositions = [];
  bool _isSubmitting = false;
  String? _aiType;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final args =
        ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
    if (args != null && args.containsKey('ai')) {
      _aiType = args['ai'] as String;
    }
  }

  void _togglePosition(String position) {
    if (_selectedPositions.contains(position)) {
      setState(() {
        _selectedPositions.remove(position);
      });
    } else {
      if (_selectedPositions.length < 5) {
        setState(() {
          _selectedPositions.add(position);
        });
      }
    }
  }

  Future<void> _submitShips() async {
    if (_selectedPositions.length != 5) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('You must place exactly 5 ships'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    setState(() {
      _isSubmitting = true;
    });

    final authModel = Provider.of<AuthModel>(context, listen: false);
    final gameModel = Provider.of<GameModel>(context, listen: false);

    if (authModel.token != null) {
      bool success = await gameModel.startGame(
        authModel.token!,
        _selectedPositions,
        ai: _aiType,
      );

      if (success && mounted) {
        Navigator.pop(context);
      } else if (mounted) {
        setState(() {
          _isSubmitting = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_aiType != null
            ? 'New Game vs ${_aiType!.toUpperCase()} AI'
            : 'New Game vs Human'),
      ),
      body: Column(
        children: [
          // Instructions
          Container(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                const Text(
                  'Place Your Ships',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Tap on the grid to place 5 ships. Tap again to remove.',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.grey.shade700,
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 6,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.blue.shade100,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Text(
                    '${_selectedPositions.length} / 5 ships placed',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.blue.shade800,
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Game board
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: BoardUtils.buildSelectorGrid(
                context: context,
                selectedPositions: _selectedPositions,
                onPositionToggle: _togglePosition,
              ),
            ),
          ),

          // Submit button
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _isSubmitting ? null : _submitShips,
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  child: _isSubmitting
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 2,
                          ),
                        )
                      : const Text(
                          'START GAME',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
