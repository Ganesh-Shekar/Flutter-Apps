import 'package:flutter/material.dart';

class BoardUtils {
  static const List<String> rows = ['A', 'B', 'C', 'D', 'E'];
  static const List<String> cols = ['1', '2', '3', '4', '5'];

  static String coordToPosition(int row, int col) {
    return '${rows[row]}${cols[col]}';
  }

  static List<int> positionToCoord(String position) {
    if (position.length != 2) return [-1, -1];

    final row = rows.indexOf(position[0]);
    final col = cols.indexOf(position[1]);

    if (row == -1 || col == -1) return [-1, -1];
    return [row, col];
  }

  static bool isValidPosition(String position) {
    if (position.length != 2) return false;
    return rows.contains(position[0]) && cols.contains(position[1]);
  }

  static Widget buildBoardCell({
    required BuildContext context,
    required int row,
    required int col,
    required bool isSelectable,
    required Function(int, int)? onTap,
    required List<String> ships,
    required List<String> wrecks,
    required List<String> shots,
    required List<String> sunk,
  }) {
    final position = coordToPosition(row, col);
    final bool isShip = ships.contains(position);
    final bool isWreck = wrecks.contains(position);
    final bool isShot = shots.contains(position);
    final bool isSunk = sunk.contains(position);

    return GestureDetector(
      onTap: isSelectable ? () => onTap?.call(row, col) : null,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.blue.shade100,
          border: Border.all(color: Colors.blue.shade800),
          borderRadius: BorderRadius.circular(4),
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            if (isShip && !isWreck)
              Icon(Icons.directions_boat,
                  color: Colors.grey.shade800, size: 24),
            if (isWreck) const Icon(Icons.circle, color: Colors.red, size: 24),
            if (isShot) const Icon(Icons.cancel, color: Colors.grey, size: 24),
            if (isSunk)
              const Icon(Icons.flight_land, color: Colors.orange, size: 24),
          ],
        ),
      ),
    );
  }

  static Widget buildSelectorCell({
    required BuildContext context,
    required int row,
    required int col,
    required bool isSelected,
    required Function(int, int) onTap,
  }) {
    return GestureDetector(
      onTap: () => onTap(row, col),
      child: Container(
        decoration: BoxDecoration(
          color: isSelected ? Colors.blue.shade300 : Colors.blue.shade100,
          border: Border.all(color: Colors.blue.shade800),
          borderRadius: BorderRadius.circular(4),
        ),
        child: isSelected
            ? Icon(Icons.directions_boat, color: Colors.grey.shade800, size: 24)
            : null,
      ),
    );
  }

  static Widget buildBoardGrid({
    required BuildContext context,
    required List<String> ships,
    required List<String> wrecks,
    required List<String> shots,
    required List<String> sunk,
    required bool isSelectable,
    required Function(String)? onCellTap,
  }) {
    final double cellSize = _calculateCellSize(context);

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Column labels
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Empty cell for top-left corner
            SizedBox(width: cellSize * 0.7, height: cellSize * 0.7),
            // Column labels
            ...List.generate(
              cols.length,
              (index) => SizedBox(
                width: cellSize,
                height: cellSize * 0.7,
                child: Center(
                  child: Text(
                    cols[index],
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
        // Board rows
        ...List.generate(
          rows.length,
          (rowIndex) => Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Row label
              SizedBox(
                width: cellSize * 0.7,
                height: cellSize,
                child: Center(
                  child: Text(
                    rows[rowIndex],
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              // Cells for this row
              ...List.generate(
                cols.length,
                (colIndex) => SizedBox(
                  width: cellSize,
                  height: cellSize,
                  child: buildBoardCell(
                    context: context,
                    row: rowIndex,
                    col: colIndex,
                    isSelectable: isSelectable,
                    onTap: (row, col) {
                      final position = coordToPosition(row, col);
                      onCellTap?.call(position);
                    },
                    ships: ships,
                    wrecks: wrecks,
                    shots: shots,
                    sunk: sunk,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  static Widget buildSelectorGrid({
    required BuildContext context,
    required List<String> selectedPositions,
    required Function(String) onPositionToggle,
  }) {
    final double cellSize = _calculateCellSize(context);

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Column labels
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Empty cell for top-left corner
            SizedBox(width: cellSize * 0.7, height: cellSize * 0.7),
            // Column labels
            ...List.generate(
              cols.length,
              (index) => SizedBox(
                width: cellSize,
                height: cellSize * 0.7,
                child: Center(
                  child: Text(
                    cols[index],
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
        // Board rows
        ...List.generate(
          rows.length,
          (rowIndex) => Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Row label
              SizedBox(
                width: cellSize * 0.7,
                height: cellSize,
                child: Center(
                  child: Text(
                    rows[rowIndex],
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                ),
              ),
              // Cells for this row
              ...List.generate(
                cols.length,
                (colIndex) {
                  final position = coordToPosition(rowIndex, colIndex);
                  final isSelected = selectedPositions.contains(position);

                  return SizedBox(
                    width: cellSize,
                    height: cellSize,
                    child: buildSelectorCell(
                      context: context,
                      row: rowIndex,
                      col: colIndex,
                      isSelected: isSelected,
                      onTap: (row, col) {
                        onPositionToggle(position);
                      },
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ],
    );
  }

  // Helper method to calculate cell size based on screen dimensions
  static double _calculateCellSize(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    // Calculate based on both width and height, taking the smaller value
    // to ensure the board fits on screen
    final widthBasedSize = (screenWidth * 0.8) / 5.7; // 80% of width
    final heightBasedSize = (screenHeight * 0.4) / 5.7; // 40% of height

    // Use the smaller of the two to ensure the board fits
    return widthBasedSize < heightBasedSize ? widthBasedSize : heightBasedSize;
  }
}
