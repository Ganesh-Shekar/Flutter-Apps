import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'dart:async';

class AuthModel extends ChangeNotifier {
  // Using a CORS proxy for web development
  static const String _actualBaseUrl = 'https://battleships-app.onrender.com';
  static String get baseUrl => kIsWeb
      ? 'https://cors-anywhere.herokuapp.com/$_actualBaseUrl'
      : _actualBaseUrl;
  static const String tokenKey = 'battleships_token';
  static const String usernameKey = 'battleships_username';

  final SharedPreferences _prefs;
  String? _token;
  String? _username;
  bool _isLoading = false;
  String? _errorMessage;

  AuthModel(this._prefs) {
    _token = _prefs.getString(tokenKey);
    _username = _prefs.getString(usernameKey);
  }

  bool get isAuthenticated => _token != null;
  bool get isLoading => _isLoading;
  String? get username => _username;
  String? get errorMessage => _errorMessage;
  String? get token => _token;

  void setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }

  void setError(String? message) {
    _errorMessage = message;
    notifyListeners();
  }

  Future<bool> login(String username, String password) async {
    setLoading(true);
    setError(null);

    try {
      final response = await http.post(
        Uri.parse('$baseUrl/login'),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          if (kIsWeb) 'X-Requested-With': 'XMLHttpRequest',
        },
        body: jsonEncode({
          'username': username,
          'password': password,
        }),
      );

      final data = jsonDecode(response.body);

      if (response.statusCode == 200) {
        _token = data['access_token'];
        _username = username;
        await _prefs.setString(tokenKey, _token!);
        await _prefs.setString(usernameKey, username);
        setLoading(false);
        notifyListeners();
        return true;
      } else {
        setError(data['message'] ?? 'Authentication failed');
        setLoading(false);
        return false;
      }
    } catch (e) {
      setError('Network error: ${e.toString()}');
      setLoading(false);
      return false;
    }
  }

  Future<bool> register(String username, String password) async {
    setLoading(true);
    setError(null);

    try {
      final response = await http
          .post(
        Uri.parse('$baseUrl/register'),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          if (kIsWeb) 'X-Requested-With': 'XMLHttpRequest',
        },
        body: jsonEncode({
          'username': username,
          'password': password,
        }),
      )
          .timeout(
        const Duration(seconds: 10),
        onTimeout: () {
          throw TimeoutException(
              'The connection has timed out, please try again.');
        },
      );

      final data = jsonDecode(response.body);

      if (response.statusCode == 200) {
        _token = data['access_token'];
        _username = username;
        await _prefs.setString(tokenKey, _token!);
        await _prefs.setString(usernameKey, username);
        setLoading(false);
        notifyListeners();
        return true;
      } else {
        setError(data['message'] ?? 'Registration failed');
        setLoading(false);
        return false;
      }
    } on TimeoutException catch (_) {
      setError(
          'Connection timed out. Please check your internet connection and try again.');
      setLoading(false);
      return false;
    } catch (e) {
      if (e.toString().contains('SocketException')) {
        setError(
            'Network error: Unable to connect to the server. Please check your internet connection.');
      } else {
        setError('Network error: ${e.toString()}');
      }
      setLoading(false);
      return false;
    }
  }

  Future<void> logout() async {
    _token = null;
    _username = null;
    await _prefs.remove(tokenKey);
    await _prefs.remove(usernameKey);
    notifyListeners();
  }

  // Method to validate token and refresh if needed
  Future<bool> validateToken() async {
    if (_token == null) {
      return false;
    }

    try {
      final response = await http.get(
        Uri.parse('$baseUrl/games'),
        headers: {'Authorization': 'Bearer $_token'},
      );

      if (response.statusCode == 401) {
        // Token expired
        _token = null;
        _username = null;
        await _prefs.remove(tokenKey);
        await _prefs.remove(usernameKey);
        notifyListeners();
        return false;
      }
      return response.statusCode == 200;
    } catch (e) {
      return false;
    }
  }
}
