import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart'; // For Colors
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:io'; // For SocketException
import 'dart:async'; // For TimeoutException
import 'auth_model.dart';

class Game {
  final int id;
  final String player1;
  final String player2;
  final int position;
  final int status;
  final int turn;
  List<String>? ships;
  List<String>? wrecks;
  List<String>? shots;
  List<String>? sunk;
  List<Map<String, dynamic>>? sunkShips;

  Game({
    required this.id,
    required this.player1,
    required this.player2,
    required this.position,
    required this.status,
    required this.turn,
    this.ships,
    this.wrecks,
    this.shots,
    this.sunk,
    this.sunkShips,
  });

  factory Game.fromJson(Map<String, dynamic> json) {
    return Game(
      id: json['id'],
      player1: json['player1'] ?? 'Waiting...',
      player2: json['player2'] ?? 'Waiting...',
      position: json['position'],
      status: json['status'],
      turn: json['turn'],
      ships: json['ships'] != null ? List<String>.from(json['ships']) : null,
      wrecks: json['wrecks'] != null ? List<String>.from(json['wrecks']) : null,
      shots: json['shots'] != null ? List<String>.from(json['shots']) : null,
      sunk: json['sunk'] != null ? List<String>.from(json['sunk']) : null,
      sunkShips: json['sunk_ships'] != null
          ? List<Map<String, dynamic>>.from(json['sunk_ships'])
          : null,
    );
  }

  String getStatusText() {
    if (status == 0) {
      return 'Matchmaking';
    } else if (status == 1) {
      return position == 1 ? 'Won' : 'Lost';
    } else if (status == 2) {
      return position == 2 ? 'Won' : 'Lost';
    } else if (status == 3) {
      if (turn == position) {
        return 'Your Turn';
      } else {
        return 'Opponent\'s Turn';
      }
    }
    return 'Unknown';
  }

  Color getStatusColor() {
    if (status == 0) {
      return Colors.orange;
    } else if ((status == 1 && position == 1) ||
        (status == 2 && position == 2)) {
      return Colors.green;
    } else if ((status == 1 && position == 2) ||
        (status == 2 && position == 1)) {
      return Colors.red;
    } else if (status == 3) {
      if (turn == position) {
        return Colors.blue;
      } else {
        return Colors.grey;
      }
    }
    return Colors.grey;
  }

  bool isActive() {
    return status == 0 || status == 3;
  }

  bool isYourTurn() {
    return status == 3 && turn == position;
  }
}

class GameModel extends ChangeNotifier {
  List<Game> _games = [];
  bool _isLoading = false;
  String? _errorMessage;
  bool _showCompletedGames = false;
  Game? _currentGame;

  List<Game> get games => _showCompletedGames
      ? _games.where((game) => game.status == 1 || game.status == 2).toList()
      : _games.where((game) => game.status == 0 || game.status == 3).toList();

  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  bool get showCompletedGames => _showCompletedGames;
  Game? get currentGame => _currentGame;

  void setCurrentGame(Game? game) {
    _currentGame = game;
    notifyListeners();
  }

  void toggleShowCompletedGames() {
    _showCompletedGames = !_showCompletedGames;
    notifyListeners();
  }

  void setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }

  void setError(String? message) {
    _errorMessage = message;
    notifyListeners();
  }

  Future<void> fetchGames(String token) async {
    setLoading(true);
    setError(null);

    try {
      final response = await http.get(
        Uri.parse('${AuthModel.baseUrl}/games'),
        headers: {'Authorization': 'Bearer $token'},
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        _games =
            List<Game>.from(data['games'].map((game) => Game.fromJson(game)));
        setLoading(false);
      } else if (response.statusCode == 401) {
        setError('Session expired. Please log in again.');
        setLoading(false);
      } else {
        setError('Failed to load games (Status: ${response.statusCode})');
        setLoading(false);
      }
    } on SocketException catch (_) {
      setError(
          'Network error: Cannot connect to the server. Please check your internet connection.');
      setLoading(false);
    } on TimeoutException catch (_) {
      setError(
          'Connection timed out. The server might be temporarily unavailable.');
      setLoading(false);
    } catch (e) {
      setError('Network error: ${e.toString()}');
      setLoading(false);
    }
  }

  Future<Game?> fetchGameDetails(String token, int gameId) async {
    setLoading(true);
    setError(null);

    try {
      final response = await http.get(
        Uri.parse('${AuthModel.baseUrl}/games/$gameId'),
        headers: {'Authorization': 'Bearer $token'},
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        _currentGame = Game.fromJson(data);
        setLoading(false);
        return _currentGame;
      } else if (response.statusCode == 401) {
        setError('Session expired. Please log in again.');
        setLoading(false);
        return null;
      } else {
        setError(
            'Failed to load game details (Status: ${response.statusCode})');
        setLoading(false);
        return null;
      }
    } on SocketException catch (_) {
      setError(
          'Network error: Cannot connect to the server. Please check your internet connection.');
      setLoading(false);
      return null;
    } on TimeoutException catch (_) {
      setError(
          'Connection timed out. The server might be temporarily unavailable.');
      setLoading(false);
      return null;
    } catch (e) {
      setError('Network error: ${e.toString()}');
      setLoading(false);
      return null;
    }
  }

  Future<bool> startGame(String token, List<String> ships, {String? ai}) async {
    setLoading(true);
    setError(null);

    try {
      final body = ai != null ? {'ships': ships, 'ai': ai} : {'ships': ships};

      final response = await http
          .post(
            Uri.parse('${AuthModel.baseUrl}/games'),
            headers: {
              'Authorization': 'Bearer $token',
              'Content-Type': 'application/json',
            },
            body: jsonEncode(body),
          )
          .timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        setLoading(false);
        return true;
      } else if (response.statusCode == 401) {
        setError('Session expired. Please log in again.');
        setLoading(false);
        return false;
      } else {
        final data = jsonDecode(response.body);
        setError(data['message'] ??
            'Failed to start game (Status: ${response.statusCode})');
        setLoading(false);
        return false;
      }
    } on SocketException catch (_) {
      setError(
          'Network error: Cannot connect to the server. Please check your internet connection.');
      setLoading(false);
      return false;
    } on TimeoutException catch (_) {
      setError(
          'Connection timed out. The server might be temporarily unavailable.');
      setLoading(false);
      return false;
    } catch (e) {
      setError('Network error: ${e.toString()}');
      setLoading(false);
      return false;
    }
  }

  Future<Map<String, dynamic>?> playShot(
      String token, int gameId, String shot) async {
    setLoading(true);
    setError(null);

    try {
      final response = await http
          .put(
            Uri.parse('${AuthModel.baseUrl}/games/$gameId'),
            headers: {
              'Authorization': 'Bearer $token',
              'Content-Type': 'application/json',
            },
            body: jsonEncode({'shot': shot}),
          )
          .timeout(const Duration(seconds: 15));

      final data = jsonDecode(response.body);

      if (response.statusCode == 200) {
        setLoading(false);
        return {
          'sunk_ship': data['sunk_ship'],
          'won': data['won'],
          'message': data['message'],
        };
      } else if (response.statusCode == 401) {
        setError('Session expired. Please log in again.');
        setLoading(false);
        return null;
      } else {
        setError(data['message'] ??
            'Failed to play shot (Status: ${response.statusCode})');
        setLoading(false);
        return null;
      }
    } on SocketException catch (_) {
      setError(
          'Network error: Cannot connect to the server. Please check your internet connection.');
      setLoading(false);
      return null;
    } on TimeoutException catch (_) {
      setError(
          'Connection timed out. The server might be temporarily unavailable.');
      setLoading(false);
      return null;
    } catch (e) {
      setError('Network error: ${e.toString()}');
      setLoading(false);
      return null;
    }
  }

  Future<bool> deleteGame(String token, int gameId) async {
    setLoading(true);
    setError(null);

    try {
      final response = await http.delete(
        Uri.parse('${AuthModel.baseUrl}/games/$gameId'),
        headers: {'Authorization': 'Bearer $token'},
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        await fetchGames(token); // Refresh games list
        setLoading(false);
        return true;
      } else if (response.statusCode == 401) {
        setError('Session expired. Please log in again.');
        setLoading(false);
        return false;
      } else {
        final data = jsonDecode(response.body);
        setError(data['message'] ??
            'Failed to delete game (Status: ${response.statusCode})');
        setLoading(false);
        return false;
      }
    } on SocketException catch (_) {
      setError(
          'Network error: Cannot connect to the server. Please check your internet connection.');
      setLoading(false);
      return false;
    } on TimeoutException catch (_) {
      setError(
          'Connection timed out. The server might be temporarily unavailable.');
      setLoading(false);
      return false;
    } catch (e) {
      setError('Network error: ${e.toString()}');
      setLoading(false);
      return false;
    }
  }
}
