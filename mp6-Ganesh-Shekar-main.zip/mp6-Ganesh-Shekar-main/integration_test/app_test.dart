import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:cs442_mp6/main.dart' as app;
import 'package:flutter/material.dart';
import 'package:cs442_mp6/services/storage_service.dart';


// This test covers the entire quiz flow, from launching the app to completing a quiz and viewing the results
void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('Integration Test', () {
    testWidgets('Complete quiz flow', (WidgetTester tester) async {
      app.main();
      await tester.pumpAndSettle();

      // Verify we're on the home screen
      expect(find.text('Trivia Time'), findsOneWidget);

      // Wait for loading indicator to disappear
      await tester.pumpAndSettle();

      // Wait for categories to load
      await tester.pump(const Duration(seconds: 2));
      await tester.pumpAndSettle();

      // Find and tap General Knowledge category
      final generalKnowledge = find.text('General Knowledge');
      expect(generalKnowledge, findsOneWidget,
          reason: 'General Knowledge category should be visible');

      await tester.tap(generalKnowledge);
      await tester.pumpAndSettle();

      // Wait for questions to load and verify we're on the quiz screen
      await tester.pump(const Duration(seconds: 2));
      await tester.pumpAndSettle();

      expect(find.byType(ElevatedButton), findsWidgets,
          reason: 'Quiz options should be visible');

      // Answer all questions
      for (int i = 1; i <= 10; i++) {
        print('\nAttempting Question $i/10');

        // Wait for the question to be fully visible
        await tester.pumpAndSettle();

        // Verify current question number
        final questionIndicator = find.text('Question $i/10');
        expect(questionIndicator, findsOneWidget,
            reason: 'Should show correct question number $i/10');

        // Find and verify answer options
        final options = find.byType(ElevatedButton);
        expect(options, findsWidgets,
            reason: 'Should find answer options for question $i');

        // Answer the current question
        await tester.tap(options.first);
        await tester.pump(); // Process the tap

        // Wait for the answer delay (2 seconds in QuizScreen)
        await tester.pump(const Duration(seconds: 2));
        await tester.pumpAndSettle(); // Wait for any animations to complete

        // If this is the last question, we should see the results screen
        if (i == 10) {
          expect(find.text('Quiz Results'), findsOneWidget,
              reason: 'Should show results screen after question 10');
          break;
        }
      }

      // Debug: Print all text widgets on screen
      print('\n=== Debug: Text widgets on screen ===');
      find.byType(Text).evaluate().forEach((element) {
        final widget = element.widget as Text;
        print('Text widget: "${widget.data}"');
      });
      print('=== End Debug ===\n');

      // Find and tap the Start New Quiz button
      final startNewQuiz = find.text('Start New Quiz');
      expect(startNewQuiz, findsOneWidget,
          reason: 'Start New Quiz button should be visible');
      await tester.tap(startNewQuiz);
      await tester.pumpAndSettle();

      // Verify we're back on the home screen
      expect(find.text('Trivia Time'), findsOneWidget);

      // Check history
      final historyButton = find.byIcon(Icons.history);
      expect(historyButton, findsOneWidget,
          reason: 'History button should be visible');
      await tester.tap(historyButton);
      await tester.pumpAndSettle();

      // Verify we're on the history screen
      expect(find.text('Quiz History'), findsOneWidget,
          reason: 'Should show Quiz History title');
    });
  });
}
