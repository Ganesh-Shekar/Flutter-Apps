# MP Report

## Team

- Name: Ganesh Prasad Chandra Shekar
- AID: A20557831

## Self-Evaluation Checklist

Tick the boxes (i.e., fill them with 'X's) that apply to your submission:

- [x] The app builds without error
- [x] I tested the app in at least one of the following platforms (check all
      that apply):
  - [x] iOS simulator / MacOS
  - [ ] Android emulator
- [x] There are at least 3 separate screens/pages in the app
- [x] There is at least one stateful widget in the app, backed by a custom model
      class using a form of state management
- [x] Some user-updateable data is persisted across application launches
- [x] Some application data is accessed from an external source and displayed in
      the app
- [x] There are at least 5 distinct unit tests, 5 widget tests, and 1
      integration test group included in the project

## Questionnaire

Answer the following questions, briefly, so that we can better evaluate your
work on this machine problem.

1. What does your app do?

   My app is a quiz application that offers a fun and interactive way to test and expand user's knowledge across various trivia categories. Users can choose from topics like General Knowledge and Entertainment, answer questions, and see how well they score. The app keeps track of your quiz history/score, so you can review your past performances and track your progress over time. With its intuitive design and engaging content, the app provides an enjoyable experience for anyone looking to challenge themselves or learn something new everyday.

2. What external data source(s) did you use? What form do they take (e.g.,
   RESTful API, cloud-based database, etc.)?

   I used the Open Trivia Database (OpenTDB) 'https://opentdb.com/' as an external data source for my app. It takes the form of a RESTful API, which allows me to fetch a wide variety of trivia questions and categories. By integrating this API, my app can offer users a diverse and engaging trivia experience with up-to-date content.

3. What additional third-party packages or libraries did you use, if any? Why?

   In my app, I used the below third-party packages to enhance functionality and streamline development:

   a. Provider: Used for state management across the app, allowing me to efficiently manage and update the app's state across different widgets.

   b. HTTP: Used to make network requests to the Open Trivia Database API, enabling the app to fetch trivia questions and categories from an external source.

   c. Shared Preferences: Used for storing simple data persistently, such as storing user's quiz history and results. SharedPreferences is also used to retrieve stored data when the app is launched.

   For development and testing, I also used:

   a. Flutter Test and Integration Test: For writing and running unit, widget, and integration tests to ensure the app functions correctly.

4. What form of local data persistence did you use?

   Used 'SharedPreferences' for local data persistence. This approach allows us to store key-value pairs persistently on the device, which is ideal for saving small amounts of data that need to be retained across app launches. Specifically, SharedPreferences is used to manage:

   - Quiz History: Storing and retrieving the user's quiz history as a JSON-encoded string.
   - Quiz Results: Managing individual quiz results as a list of JSON-encoded strings, allowing for easy access and manipulation.
     SharedPreferences provides a simple and efficient way to handle persistent data without the complexity of a full database solution, making it suitable for the needs of your application.

5. What workflow is tested by your integration test?

   My integration test covers the following detailed workflow:

   a. App Launch: The test begins by launching the app and confirming that the home screen is displayed correctly with the "Trivia Time" text, indicating that the app has loaded successfully.

   b. Category Selection: It simulates a user selecting the "General Knowledge" category to start a quiz, ensuring that category selection is functioning as expected.

   c. Quiz Interaction: During the quiz, the test:

   - Iterates through 10 questions, simulating user interactions by selecting answers.

   - Verifies that the quiz progresses correctly by checking the question number indicator.

   - Ensures that the quiz advances smoothly from one question to the next.

   d. Results Screen Verification: After the last question, the test checks that the results screen is displayed, confirming that the quiz completion process works as intended.

   e. Starting a New Quiz: The test verifies that users can start a new quiz by tapping the "Start New Quiz" button, which returns them to the home screen.

   f. History Screen Navigation: Finally, the test navigates to the history screen by tapping the history button and verifies that the "Quiz History" title is displayed, ensuring that users can view their past quiz results.

## Summary and Reflection

In my app, I made several notable implementation decisions to enhance functionality and user experience. I chose to use the Open Trivia Database API for fetching trivia questions, which provided a diverse range of categories and questions. For state management, I utilized the Provider package, allowing for efficient and scalable state handling across the app. I implemented local data persistence using Shared Preferences for simple key-value storage and Sqflite for more complex data needs, ensuring data is retained across app launches.
To run Unit and Widget tests please use: `flutter test`

To run Integration tests use the command: `flutter test integration_test/app_test.dart`

Working on this project was both an enjoyable and enlightening experience. I particularly enjoyed the process of integrating the Open Trivia Database API, as it allowed me to explore and implement a wide variety of trivia content, making the app more engaging for users. The use of Flutter's Provider package for state management was also rewarding, as it provided a clean and efficient way to manage app state. However, I found some aspects challenging, especially optimizing the app's performance when handling large amounts of data. Ensuring a smooth and responsive user interface required careful consideration and testing, which was a learning curve. Overall, this project was a valuable learning experience, and I'm excited to apply what I've learned to future projects.
