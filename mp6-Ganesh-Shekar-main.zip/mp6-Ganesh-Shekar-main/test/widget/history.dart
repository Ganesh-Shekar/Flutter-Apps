import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:cs442_mp6/screens/history_screen.dart';
import 'package:cs442_mp6/models/trivia_model.dart';
import 'dart:convert';

// It checks the display of quiz results and empty state
void main() {
  testWidgets('HistoryScreen shows empty state when no results',
      (WidgetTester tester) async {
    SharedPreferences.setMockInitialValues({'quiz_results': <String>[]});

    await tester.pumpWidget(
      const MaterialApp(home: HistoryScreen()),
    );
    await tester.pumpAndSettle();

    expect(find.text('Quiz History'), findsOneWidget);
    expect(find.text('No quiz history yet'), findsOneWidget);
    expect(find.text('Complete some quizzes to see your history here'),
        findsOneWidget);
  });

  testWidgets('HistoryScreen displays quiz results correctly',
      (WidgetTester tester) async {
    final now = DateTime.now();
    final mockResults = [
      jsonEncode({
        'category': '9',
        'score': 5,
        'totalQuestions': 10,
        'date': now.toIso8601String(),
      })
    ];

    SharedPreferences.setMockInitialValues({
      'quiz_results': mockResults,
    });

    await tester.pumpWidget(
      const MaterialApp(home: HistoryScreen()),
    );
    await tester.pumpAndSettle();

    // Verify the category name is displayed
    expect(find.text('General Knowledge'), findsOneWidget);

    // Verify the score is displayed (in the CircleAvatar)
    expect(find.text('5'), findsOneWidget);

    // Verify the category icon is present
    expect(find.byIcon(Icons.category_outlined), findsOneWidget);

    // Verify the formatted date is displayed
    final months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec'
    ];
    final expectedDate = '${months[now.month - 1]} ${now.day}, ${now.year}';
    expect(find.text(expectedDate), findsOneWidget);
  });
}
