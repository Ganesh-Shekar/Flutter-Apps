import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:cs442_mp6/models/trivia_model.dart';
import 'package:cs442_mp6/services/storage_service.dart';
import 'package:cs442_mp6/services/trivia_service.dart';
import 'package:cs442_mp6/screens/quiz_screen.dart';

// it tests the basic functionality of the QuizScreen
class MockTriviaService implements TriviaService {
  @override
  Future<Map<String, dynamic>> getCategories() async => {
        'trivia_categories': [
          {'id': 9, 'name': 'General Knowledge'},
          {'id': 10, 'name': 'Books'},
          {'id': 11, 'name': 'Film'},
        ]
      };

  @override
  Future<List<Map<String, dynamic>>> getQuestions(String category) async {
    // Return immediately for testing
    return [
      {
        'question': 'What is the capital of France?',
        'correct_answer': 'Paris',
        'incorrect_answers': ['London', 'Berlin', 'Madrid'],
      }
    ];
  }

  @override
  Future<Map<String, dynamic>> getCategoryQuestionCount(
          String category) async =>
      {
        'category_id': category,
        'category_question_count': {
          'total_question_count': 10,
          'total_easy_question_count': 3,
          'total_medium_question_count': 4,
          'total_hard_question_count': 3,
        }
      };
}

class MockStorageService extends StorageService {
  List<Map<String, dynamic>> _history = [];
  List<Map<String, dynamic>> _results = [];

  @override
  Future<List<Map<String, dynamic>>> getHistory() async => _history;

  @override
  Future<List<Map<String, dynamic>>> getResults() async => _results;

  @override
  Future<void> saveHistory(List<Map<String, dynamic>> history) async {
    _history = history;
  }

  @override
  Future<void> saveResult(Map<String, dynamic> result) async {
    _results.add(result);
  }

  @override
  Future<void> clearResults() async {
    _results.clear();
  }
}

void main() {
  late TriviaModel model;
  late MockStorageService storageService;
  late MockTriviaService triviaService;

  setUp(() {
    storageService = MockStorageService();
    triviaService = MockTriviaService();
    model = TriviaModel(
      storageService: storageService,
      triviaService: triviaService,
    );
  });

  Future<void> pumpQuizScreen(WidgetTester tester) async {
    await tester.pumpWidget(
      ChangeNotifierProvider<TriviaModel>.value(
        value: model,
        child: MaterialApp(
          home: const QuizScreen(
            answerDelay: Duration(milliseconds: 0), // No delay for testing
          ),
        ),
      ),
    );
  }

  testWidgets('QuizScreen basic functionality test',
      (WidgetTester tester) async {
    // Load questions before pumping widget to avoid loading state
    await model.loadQuestions('9');
    await pumpQuizScreen(tester);

    // Wait for initial build
    await tester.pump();

    // 1. Test question display
    expect(find.text('What is the capital of France?'), findsOneWidget);
    expect(find.text('Paris'), findsOneWidget);
    expect(find.text('Question 1/1'), findsOneWidget);

    // 2. Test answer selection
    await tester.tap(find.text('Paris'));
    // Wait for state to update after tap
    await tester.pump();
    // Wait for the answer delay (we set it to 0ms in test setup)
    await tester.pump(const Duration(milliseconds: 1));

    expect(model.score, 1);
  });

  testWidgets('QuizScreen error state test', (WidgetTester tester) async {
    model.questions = [];
    await pumpQuizScreen(tester);
    await tester.pump();

    expect(find.text('No questions available'), findsOneWidget);
    expect(find.text('Go Back'), findsOneWidget);
  });
}
