import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:cs442_mp6/screens/home_screen.dart';  // Contains GradientText

// checks that GradientText displays the given text
void main() {
  testWidgets('GradientText displays given text', (WidgetTester tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: GradientText(
            'Hello',
            style: const TextStyle(fontSize: 24),
            gradient: const LinearGradient(colors: [Colors.red, Colors.blue]),
          ),
        ),
      ),
    );
    expect(find.text('Hello'), findsOneWidget);
  });
}