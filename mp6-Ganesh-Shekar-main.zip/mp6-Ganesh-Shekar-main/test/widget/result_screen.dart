import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:cs442_mp6/screens/results_screen.dart';
import 'package:cs442_mp6/models/trivia_model.dart';

// It verifies that the ResultsScreen displays the score and stats
void main() {
  testWidgets('ResultsScreen displays score and stats', (WidgetTester tester) async {
    SharedPreferences.setMockInitialValues({'quiz_results': <String>[]});
    final model = TriviaModel();
    model.questions = [
      {'question': 'Q1', 'correct_answer': 'A', 'incorrect_answers': []},
    ];
    model.currentCategory = '9';
    model.score = 1;

    await tester.pumpWidget(
      ChangeNotifierProvider<TriviaModel>.value(
        value: model,
        child: MaterialApp(home: ResultsScreen()),
      ),
    );
    await tester.pumpAndSettle();
    expect(find.text('Quiz Results'), findsOneWidget);
    expect(find.text('1/1'), findsWidgets);
    expect(find.text('Accuracy'), findsOneWidget);
  });
}