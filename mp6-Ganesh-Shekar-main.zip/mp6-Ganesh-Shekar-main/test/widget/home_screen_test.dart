import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:cs442_mp6/models/trivia_model.dart';
import 'package:cs442_mp6/services/storage_service.dart';
import 'package:cs442_mp6/services/trivia_service.dart';
import 'package:cs442_mp6/screens/home_screen.dart';

// This tests the loading indicator, category display, and search functionality
class MockTriviaService implements TriviaService {
  @override
  Future<Map<String, dynamic>> getCategories() async {
    // Add a small delay to simulate network latency
    await Future.delayed(const Duration(milliseconds: 100));
    final categories = {
      'trivia_categories': [
        {'id': 9, 'name': 'General Knowledge'},
        {'id': 10, 'name': 'Entertainment: Books'},
        {'id': 11, 'name': 'Entertainment: Film'},
      ]
    };
    print('Mock getCategories called, returning: $categories');
    return categories;
  }

  @override
  Future<List<Map<String, dynamic>>> getQuestions(String category) async {
    return [];
  }

  @override
  Future<Map<String, dynamic>> getCategoryQuestionCount(
          String category) async =>
      {
        'category_id': category,
        'category_question_count': {
          'total_question_count': 10,
          'total_easy_question_count': 3,
          'total_medium_question_count': 4,
          'total_hard_question_count': 3,
        }
      };
}

class MockStorageService extends StorageService {
  List<Map<String, dynamic>> _history = [];
  List<Map<String, dynamic>> _results = [];

  @override
  Future<List<Map<String, dynamic>>> getHistory() async => _history;

  @override
  Future<List<Map<String, dynamic>>> getResults() async => _results;

  @override
  Future<void> saveHistory(List<Map<String, dynamic>> history) async {
    _history = history;
  }

  @override
  Future<void> saveResult(Map<String, dynamic> result) async {
    _results.add(result);
  }

  @override
  Future<void> clearResults() async {
    _results.clear();
  }
}

void main() {
  testWidgets('HomeScreen shows loading indicator and then categories',
      (WidgetTester tester) async {
    // Set a larger viewport size
    tester.binding.window.physicalSizeTestValue = Size(1080, 1920);
    tester.binding.window.devicePixelRatioTestValue = 1.0;
    addTearDown(tester.binding.window.clearPhysicalSizeTestValue);

    // Create mock services
    final mockTriviaService = MockTriviaService();
    final mockStorageService = MockStorageService();

    // Build our app and trigger a frame.
    await tester.pumpWidget(
      MaterialApp(
        home: MultiProvider(
          providers: [
            ChangeNotifierProvider(
              create: (_) => TriviaModel(
                storageService: mockStorageService,
                triviaService: mockTriviaService,
              ),
            ),
          ],
          child: HomeScreen(triviaService: mockTriviaService),
        ),
      ),
    );

    // Initially, we should see a loading indicator
    expect(find.byType(CircularProgressIndicator), findsOneWidget);
    print('Found loading indicator');

    // Wait for the loading indicator to disappear and categories to load
    await tester.pump(const Duration(milliseconds: 500));
    await tester.pumpAndSettle();
    print('Waited for loading to complete');

    // After loading, we should see the welcome text
    expect(find.text('Welcome back!'), findsOneWidget);
    print('Found welcome text');

    expect(
      find.text(
          'Challenge yourself with our diverse collection of trivia categories.'),
      findsOneWidget,
    );
    print('Found challenge text');

    // We should see the search field
    expect(find.byType(TextField), findsOneWidget);
    print('Found search field');

    // We should see the category title
    expect(find.text('Featured Categories'), findsOneWidget);
    print('Found Featured Categories text');

    // Debug print all Text widgets in the tree
    print('\nAll Text widgets in the tree:');
    tester.widgetList<Text>(find.byType(Text)).forEach((widget) {
      print('Text: "${widget.data}"');
      if (widget.key != null) {
        print('  Key: ${widget.key}');
      }
    });

    // Check for category texts by their ValueKey
    expect(find.byKey(const ValueKey('category_title_General Knowledge')),
        findsOneWidget);
    expect(find.byKey(const ValueKey('category_title_Entertainment: Books')),
        findsOneWidget);
    expect(find.byKey(const ValueKey('category_title_Entertainment: Film')),
        findsOneWidget);
  });

  testWidgets('HomeScreen search functionality works correctly',
      (WidgetTester tester) async {
    // Set a larger viewport size
    tester.binding.window.physicalSizeTestValue = Size(1080, 1920);
    tester.binding.window.devicePixelRatioTestValue = 1.0;
    addTearDown(tester.binding.window.clearPhysicalSizeTestValue);

    // Create mock services
    final mockTriviaService = MockTriviaService();
    final mockStorageService = MockStorageService();

    // Build our app and trigger a frame.
    await tester.pumpWidget(
      MaterialApp(
        home: MultiProvider(
          providers: [
            ChangeNotifierProvider(
              create: (_) => TriviaModel(
                storageService: mockStorageService,
                triviaService: mockTriviaService,
              ),
            ),
          ],
          child: HomeScreen(triviaService: mockTriviaService),
        ),
      ),
    );

    // Wait for the loading to complete
    await tester.pump(const Duration(milliseconds: 500));
    await tester.pumpAndSettle();
    print('Waited for loading to complete');

    // Debug print all Text widgets in the tree before search
    print('\nAll Text widgets in the tree before search:');
    tester.widgetList<Text>(find.byType(Text)).forEach((widget) {
      print('Text: "${widget.data}"');
      if (widget.key != null) {
        print('  Key: ${widget.key}');
      }
    });

    // Find the search field
    final searchField = find.byType(TextField);
    expect(searchField, findsOneWidget);

    // Check for category texts by their ValueKey before search
    expect(find.byKey(const ValueKey('category_title_General Knowledge')),
        findsOneWidget);
    expect(find.byKey(const ValueKey('category_title_Entertainment: Books')),
        findsOneWidget);
    expect(find.byKey(const ValueKey('category_title_Entertainment: Film')),
        findsOneWidget);

    // Test search functionality
    await tester.enterText(find.byType(TextField), 'Book');
    await tester.pumpAndSettle();

    // Debug print all Text widgets after search
    print('\nAll Text widgets in the tree after search:');
    tester.widgetList<Text>(find.byType(Text)).forEach((widget) {
      print('Text: "${widget.data}"');
      if (widget.key != null) {
        print('  Key: ${widget.key}');
      }
    });

    // After searching for 'Book', we should only see 'Entertainment: Books'
    expect(find.byKey(const ValueKey('category_title_Entertainment: Books')),
        findsOneWidget);
    expect(find.byKey(const ValueKey('category_title_General Knowledge')),
        findsNothing);
    expect(find.byKey(const ValueKey('category_title_Entertainment: Film')),
        findsNothing);

    // Clear the search
    await tester.enterText(find.byType(TextField), '');
    await tester.pumpAndSettle();

    // Debug print all Text widgets after clearing search
    print('\nAll Text widgets in the tree after clearing search:');
    tester.widgetList<Text>(find.byType(Text)).forEach((widget) {
      print('Text: "${widget.data}"');
      if (widget.key != null) {
        print('  Key: ${widget.key}');
      }
    });

    // All categories should be visible again
    expect(find.byKey(const ValueKey('category_title_General Knowledge')),
        findsOneWidget);
    expect(find.byKey(const ValueKey('category_title_Entertainment: Books')),
        findsOneWidget);
    expect(find.byKey(const ValueKey('category_title_Entertainment: Film')),
        findsOneWidget);
  });
}
