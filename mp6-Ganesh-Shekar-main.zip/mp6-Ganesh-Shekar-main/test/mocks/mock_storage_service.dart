import 'package:cs442_mp6/services/storage_service.dart';

class MockStorageService extends StorageService {
  List<Map<String, dynamic>> _history = [];
  List<Map<String, dynamic>> _results = [];

  @override
  Future<List<Map<String, dynamic>>> getHistory() async {
    return _history;
  }

  @override
  Future<void> saveHistory(List<Map<String, dynamic>> history) async {
    _history = history;
  }

  @override
  Future<void> saveResult(Map<String, dynamic> result) async {
    _results.add(result);
  }

  @override
  Future<List<Map<String, dynamic>>> getResults() async {
    return _results;
  }

  @override
  Future<void> clearResults() async {
    _results.clear();
  }
}
