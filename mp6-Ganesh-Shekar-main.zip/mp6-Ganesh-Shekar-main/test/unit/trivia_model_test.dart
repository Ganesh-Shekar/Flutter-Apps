import 'package:flutter_test/flutter_test.dart';
import 'package:cs442_mp6/models/trivia_model.dart';
import 'package:cs442_mp6/services/trivia_service.dart';
import 'package:cs442_mp6/services/storage_service.dart';

class FakeTriviaService extends TriviaService {
  @override
  Future<List<Map<String, dynamic>>> getQuestions(String category) async {
    return [
      {
        'question': 'Q1',
        'correct_answer': 'A',
        'incorrect_answers': ['B', 'C', 'D'],
      },
      {
        'question': 'Q2',
        'correct_answer': 'B',
        'incorrect_answers': ['A', 'C', 'D'],
      },
    ];
  }
}

class FakeStorageService extends StorageService {
  final List<Map<String, dynamic>> _history = [];

  @override
  Future<List<Map<String, dynamic>>> getHistory() async => _history;

  @override
  Future<void> saveResult(Map<String, dynamic> result) async {
    _history.add(result);
  }
}

void main() {
  group('TriviaModel unit tests', () {
    late TriviaModel model;
    late FakeTriviaService triviaService;
    late FakeStorageService storageService;

    setUp(() {
      triviaService = FakeTriviaService();
      storageService = FakeStorageService();
      model = TriviaModel(
        triviaService: triviaService,
        storageService: storageService,
      );
    });

    // Verifies that the initial values of the TriviaModel are correct.
    test('initial values are correct', () {
      expect(model.questions, isEmpty);
      expect(model.score, 0);
      expect(model.currentQuestionIndex, 0);
      expect(model.isLastQuestion, isFalse);
      expect(model.currentQuestion, isEmpty);
    });

    // Verifies that loadQuestions populates questions and updates state.
    test('loadQuestions populates questions and updates state', () async {
      await model.loadQuestions('test');
      expect(model.questions.length, 2);
      expect(model.currentCategory, 'test');
      expect(model.score, 0);
      expect(model.currentQuestionIndex, 0);
      expect(model.isLoading, isFalse);
    });

    // Verifies that answerQuestion increments score when correct and advances index.
    test('answerQuestion increments score when correct and advances index', () {
      model.questions = [
        {'question': 'Q1', 'correct_answer': 'A', 'incorrect_answers': []},
        {'question': 'Q2', 'correct_answer': 'B', 'incorrect_answers': []},
      ];
      model.answerQuestion(true);
      expect(model.score, 1);
      expect(model.currentQuestionIndex, 1);
    });

    // Verifies that isLastQuestion reports true on the last index.
    test('isLastQuestion reports true on last index', () {
      model.questions = [
        {'question': 'Q1', 'correct_answer': 'A', 'incorrect_answers': []},
      ];
      expect(model.isLastQuestion, isTrue);
    });

// Verifies that saveResult stores the result and updates history.
    test('saveResult stores result and updates history', () async {
      model.questions = [
        {'question': 'Q1', 'correct_answer': 'A', 'incorrect_answers': []},
      ];
      model.currentCategory = '1';
      model.score = 1;
      await model.saveResult();
      final history = await storageService.getHistory();
      expect(history, hasLength(1));
      final result = history.first;
      expect(result['category'], '1');
      expect(result['score'], 1);
      expect(result['totalQuestions'], 1);
      expect(model.history.length, 1);
    });
  });
}
