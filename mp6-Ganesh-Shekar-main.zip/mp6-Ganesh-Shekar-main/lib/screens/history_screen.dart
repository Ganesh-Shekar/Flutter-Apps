import 'package:flutter/material.dart';
import '../services/storage_service.dart';

// This file defines the HistoryScreen widget, which displays the user's quiz history. It shows past quiz results, including scores and categories, allowing users to review their performance over time
class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  final StorageService _storageService = StorageService();

  String _getCategoryName(String categoryId) {
    switch (categoryId) {
      case '9':
        return 'General Knowledge';
      case '10':
        return 'Entertainment: Books';
      case '11':
        return 'Entertainment: Film';
      case '12':
        return 'Entertainment: Music';
      case '13':
        return 'Entertainment: Musicals & Theatre';
      case '14':
        return 'Entertainment: Television';
      case '15':
        return 'Entertainment: Video Games';
      case '16':
        return 'Entertainment: Board Games';
      case '17':
        return 'Science & Nature';
      case '18':
        return 'Science: Computers';
      case '19':
        return 'Science: Mathematics';
      case '20':
        return 'Mythology';
      case '21':
        return 'Sports';
      case '22':
        return 'Geography';
      case '23':
        return 'History';
      case '24':
        return 'Politics';
      case '25':
        return 'Art';
      case '26':
        return 'Celebrities';
      case '27':
        return 'Animals';
      case '28':
        return 'Vehicles';
      case '29':
        return 'Entertainment: Comics';
      case '30':
        return 'Science: Gadgets';
      case '31':
        return 'Entertainment: Japanese Anime & Manga';
      case '32':
        return 'Entertainment: Cartoon & Animation';
      default:
        return 'Unknown Category';
    }
  }

  IconData _getCategoryIcon(String categoryName) {
    switch (categoryName.toLowerCase()) {
      case 'general knowledge':
        return Icons.lightbulb_outline;
      case 'science & nature':
        return Icons.science_outlined;
      case 'history':
        return Icons.history_edu_outlined;
      case 'sports':
        return Icons.sports_outlined;
      case 'geography':
        return Icons.public_outlined;
      case 'entertainment':
        return Icons.movie_outlined;
      case 'art':
        return Icons.palette_outlined;
      case 'politics':
        return Icons.gavel_outlined;
      case 'animals':
        return Icons.pets_outlined;
      case 'vehicles':
        return Icons.directions_car_outlined;
      case 'mythology':
        return Icons.auto_awesome_outlined;
      case 'celebrities':
        return Icons.star_outline;
      case 'mathematics':
        return Icons.calculate_outlined;
      case 'television':
        return Icons.tv_outlined;
      case 'music':
        return Icons.music_note_outlined;
      case 'books':
        return Icons.book_outlined;
      case 'film':
        return Icons.movie_creation_outlined;
      case 'video games':
        return Icons.videogame_asset_outlined;
      case 'board games':
        return Icons.casino_outlined;
      case 'comics':
        return Icons.auto_stories_outlined;
      case 'gadgets':
        return Icons.devices_outlined;
      case 'anime & manga':
        return Icons.animation_outlined;
      default:
        return Icons.category_outlined;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.background,
      appBar: AppBar(
        title: const Text('Quiz History'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_outline),
            tooltip: 'Clear History',
            onPressed: () {
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  title: const Text('Clear History'),
                  content: const Text(
                      'Are you sure you want to clear your quiz history? This action cannot be undone.'),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('Cancel'),
                    ),
                    TextButton(
                      onPressed: () async {
                        await _storageService.clearResults();
                        if (mounted) {
                          Navigator.pop(context);
                          setState(() {}); // Refresh the screen
                        }
                      },
                      child: Text(
                        'Clear',
                        style: TextStyle(
                          color: Theme.of(context).colorScheme.error,
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: FutureBuilder<List<Map<String, dynamic>>>(
          future: _storageService.getResults(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(
                child: CircularProgressIndicator.adaptive(),
              );
            }

            if (snapshot.hasError) {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.error_outline,
                      size: 48,
                      color: Theme.of(context).colorScheme.error,
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'Error loading history',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      snapshot.error.toString(),
                      style: Theme.of(context).textTheme.bodyMedium,
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              );
            }

            if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.history_outlined,
                      size: 64,
                      color: Theme.of(context)
                          .colorScheme
                          .primary
                          .withOpacity(0.5),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'No quiz history yet',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Complete some quizzes to see your history here',
                      style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                            color: Theme.of(context)
                                .colorScheme
                                .onSurface
                                .withOpacity(0.7),
                          ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              );
            }

            final results = List<Map<String, dynamic>>.from(snapshot.data!);
            results.sort((a, b) {
              // Get the original ISO date string before it was formatted
              final dateA = a['originalDate'] ?? a['date'];
              final dateB = b['originalDate'] ?? b['date'];
              return DateTime.parse(dateB).compareTo(DateTime.parse(dateA));
            });

            return ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: results.length,
              itemBuilder: (context, index) {
                final result = results[index];
                final categoryName = _getCategoryName(result['category']);
                final icon = _getCategoryIcon(categoryName);
                final score = result['score'];
                final total = result['totalQuestions'];
                final date = result['date'];
                final percentage = (score / total * 100).round();

                return Card(
                  margin: const EdgeInsets.only(bottom: 16),
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor:
                          Theme.of(context).colorScheme.primaryContainer,
                      child: Icon(
                        icon,
                        color: Theme.of(context).colorScheme.primary,
                      ),
                    ),
                    title: Text(categoryName),
                    subtitle: Text(date),
                    trailing: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          '$percentage%',
                          style:
                              Theme.of(context).textTheme.titleMedium?.copyWith(
                                    color: percentage >= 70
                                        ? Colors.green
                                        : percentage >= 40
                                            ? Colors.orange
                                            : Colors.red,
                                  ),
                        ),
                        Text(
                          '$score/$total correct',
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
