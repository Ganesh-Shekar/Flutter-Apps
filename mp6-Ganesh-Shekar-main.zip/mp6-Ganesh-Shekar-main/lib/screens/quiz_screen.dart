import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/trivia_model.dart';
import 'results_screen.dart';

// This file defines the QuizScreen widget, which manages the quiz-taking experience. It displays questions, handles user interactions for selecting answers, and progresses through the quiz
class QuizScreen extends StatefulWidget {
  final Duration answerDelay;

  const QuizScreen({
    super.key,
    this.answerDelay = const Duration(seconds: 2),
  });

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  String? selectedAnswer;
  bool showAnswer = false;
  List<String> shuffledOptions = [];

  void _shuffleOptions(Map<String, dynamic> question) {
    if (shuffledOptions.isEmpty) {
      shuffledOptions = [
        ...question['incorrect_answers'],
        question['correct_answer'],
      ]..shuffle();
    }
  }

  void _handleAnswer(BuildContext context, TriviaModel model, String answer) {
    if (showAnswer) return; // Prevent multiple selections

    setState(() {
      selectedAnswer = answer;
      showAnswer = true;
    });

    // Delay moving to next question to show the answer
    Future.delayed(widget.answerDelay, () {
      if (!mounted) return;

      final isCorrect = answer == model.currentQuestion['correct_answer'];
      final wasLastQuestion =
          model.isLastQuestion; // Check before updating model

      model.answerQuestion(isCorrect);

      if (wasLastQuestion) {
        model.saveResult();
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => const ResultsScreen(),
          ),
        );
      } else {
        setState(() {
          selectedAnswer = null;
          showAnswer = false;
          shuffledOptions = []; // Clear options for next question
        });
      }
    });
  }

  Color _getAnswerColor(
      BuildContext context, String answer, String correctAnswer) {
    if (!showAnswer) return Theme.of(context).colorScheme.surface;

    if (answer == correctAnswer) {
      return Colors.green.shade100;
    }
    if (answer == selectedAnswer && answer != correctAnswer) {
      return Colors.red.shade100;
    }
    return Theme.of(context).colorScheme.surface;
  }

  Color _getTextColor(
      BuildContext context, String answer, String correctAnswer) {
    if (!showAnswer) return Theme.of(context).colorScheme.onSurface;

    if (answer == correctAnswer) {
      return Colors.green.shade900;
    }
    if (answer == selectedAnswer && answer != correctAnswer) {
      return Colors.red.shade900;
    }
    return Theme.of(context).colorScheme.onSurface;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFFF5F7FF), // Light blue-tinted white
              Color(0xFFE6EAFE), // Very light periwinkle
              Color(0xFFEDF1FF), // Soft blue-white
            ],
            stops: const [0.0, 0.5, 1.0],
          ),
        ),
        child: SafeArea(
          child: Consumer<TriviaModel>(
            builder: (context, model, child) {
              if (model.isLoading) {
                return const Center(
                  child: CircularProgressIndicator.adaptive(),
                );
              }

              if (model.questions.isEmpty) {
                return Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.error_outline,
                        size: 48,
                        color: Theme.of(context).colorScheme.error,
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'No questions available',
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                      const SizedBox(height: 24),
                      FilledButton.icon(
                        onPressed: () => Navigator.pop(context),
                        icon: const Icon(Icons.arrow_back),
                        label: const Text('Go Back'),
                      ),
                    ],
                  ),
                );
              }

              final question = model.currentQuestion;
              _shuffleOptions(question);

              return Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        IconButton(
                          onPressed: () => Navigator.pop(context),
                          icon: const Icon(Icons.close),
                        ),
                        Text(
                          'Question ${model.currentQuestionIndex + 1}/${model.questions.length}',
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                        const SizedBox(width: 48),
                      ],
                    ),
                  ),
                  LinearProgressIndicator(
                    value: (model.currentQuestionIndex + 1) /
                        model.questions.length,
                    backgroundColor: Theme.of(context)
                        .colorScheme
                        .primaryContainer
                        .withOpacity(0.3),
                  ),
                  const SizedBox(height: 32),
                  Expanded(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.symmetric(horizontal: 24),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            question['question'],
                            style: Theme.of(context)
                                .textTheme
                                .headlineSmall
                                ?.copyWith(
                                  height: 1.3,
                                ),
                          ),
                          const SizedBox(height: 32),
                          ...shuffledOptions.map((option) {
                            final isCorrect =
                                option == question['correct_answer'];
                            final isSelected = option == selectedAnswer;

                            return Padding(
                              padding: const EdgeInsets.only(bottom: 16),
                              child: AnimatedScale(
                                scale: 1.0,
                                duration: const Duration(milliseconds: 200),
                                child: ElevatedButton(
                                  onPressed: showAnswer
                                      ? null
                                      : () =>
                                          _handleAnswer(context, model, option),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: _getAnswerColor(context,
                                        option, question['correct_answer']),
                                    foregroundColor: _getTextColor(context,
                                        option, question['correct_answer']),
                                    elevation: 0,
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 24,
                                      vertical: 16,
                                    ),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12),
                                      side: BorderSide(
                                        color: showAnswer && isCorrect
                                            ? Colors.green.shade300
                                            : showAnswer &&
                                                    isSelected &&
                                                    !isCorrect
                                                ? Colors.red.shade300
                                                : Theme.of(context)
                                                    .colorScheme
                                                    .outline
                                                    .withOpacity(0.2),
                                        width: showAnswer &&
                                                (isCorrect || isSelected)
                                            ? 2
                                            : 1,
                                      ),
                                    ),
                                    disabledBackgroundColor: _getAnswerColor(
                                        context,
                                        option,
                                        question['correct_answer']),
                                    disabledForegroundColor: _getTextColor(
                                        context,
                                        option,
                                        question['correct_answer']),
                                  ),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: Text(
                                          option,
                                          style: Theme.of(context)
                                              .textTheme
                                              .bodyLarge
                                              ?.copyWith(
                                                color: _getTextColor(
                                                    context,
                                                    option,
                                                    question['correct_answer']),
                                                fontWeight: showAnswer &&
                                                        (isCorrect ||
                                                            isSelected)
                                                    ? FontWeight.bold
                                                    : null,
                                              ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          }),
                        ],
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}
