import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/trivia_model.dart';
import '../services/trivia_service.dart';
import 'quiz_screen.dart';
import 'history_screen.dart';

// This file defines the HomeScreen widget, which serves as the main entry point for users. It displays a list of trivia categories and allows users to navigate to different parts of the app, such as starting a quiz or viewing their quiz history
class HomeScreen extends StatefulWidget {
  final TriviaService? triviaService;

  const HomeScreen({super.key, this.triviaService});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late final TriviaService _triviaService;
  List<Map<String, dynamic>> _categories = [];
  List<Map<String, dynamic>> _filteredCategories = [];
  bool _isLoading = true;
  String? _error;
  final TextEditingController _searchController = TextEditingController();

  // Define category colors based on themes
  List<List<Color>> _categoryColors = [
    [Color(0xFFFFB5B5), Color(0xFFFF8080)], // Entertainment
    [Color(0xFFB5FFB5), Color(0xFF80FF80)], // Science
    [Color(0xFFB5B5FF), Color(0xFF8080FF)], // History & Geography
    [Color(0xFFFFE5B5), Color(0xFFFFCC66)], // Sports & Games
    [Color(0xFFE5B5FF), Color(0xFFCC66FF)], // Arts & Culture
    [Color(0xFFB5E5FF), Color(0xFF66CCFF)], // Technology
    [Color(0xFFFFB5E5), Color(0xFFFF66CC)], // Mythology & Religion
    [Color(0xFFB5FFE5), Color(0xFF66FFCC)], // Nature & Animals
  ];

  List<Color> _getCategoryColors(String categoryId) {
    // Group categories by theme
    switch (categoryId) {
      case '10': // Books
      case '11': // Film
      case '12': // Music
      case '13': // Musicals & Theatre
      case '14': // Television
      case '31': // Anime & Manga
      case '32': // Cartoons
        return _categoryColors[0];

      case '17': // Science & Nature
      case '18': // Computers
      case '19': // Mathematics
        return _categoryColors[1];

      case '23': // History
      case '22': // Geography
        return _categoryColors[2];

      case '21': // Sports
      case '15': // Video Games
      case '16': // Board Games
        return _categoryColors[3];

      case '25': // Art
      case '26': // Celebrities
      case '29': // Comics
        return _categoryColors[4];

      case '30': // Gadgets
        return _categoryColors[5];

      case '20': // Mythology
        return _categoryColors[6];

      case '27': // Animals
      case '28': // Vehicles
        return _categoryColors[7];

      case '9': // General Knowledge
      default:
        // Create a unique gradient for general knowledge
        return [Color(0xFFB5D5FF), Color(0xFF66A3FF)];
    }
  }

  @override
  void initState() {
    super.initState();
    _triviaService = widget.triviaService ?? TriviaService();
    _loadCategories();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadCategories() async {
    try {
      final response = await _triviaService.getCategories();
      setState(() {
        _categories =
            List<Map<String, dynamic>>.from(response['trivia_categories']);
        _filteredCategories = _categories;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _isLoading = false;
      });
    }
  }

  void _filterCategories(String query) {
    setState(() {
      _filteredCategories = _categories
          .where((category) => category['name']
              .toString()
              .toLowerCase()
              .contains(query.toLowerCase()))
          .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.background,
      body: CustomScrollView(
        slivers: [
          SliverAppBar.large(
            floating: true,
            pinned: true,
            expandedHeight: 120,
            actions: [
              IconButton(
                icon: const Icon(Icons.history),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const HistoryScreen(),
                    ),
                  );
                },
              ),
              const SizedBox(width: 8),
            ],
            flexibleSpace: FlexibleSpaceBar(
              title: GradientText(
                'Trivia Time',
                style: const TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  shadows: [
                    Shadow(
                      color: Colors.black26,
                      offset: Offset(2, 2),
                      blurRadius: 4,
                    ),
                  ],
                ),
                gradient: LinearGradient(
                  colors: [
                    Color(0xFF64B5F6), // Light Blue
                    Color(0xFF2196F3), // Blue
                    Color(0xFF1976D2), // Dark Blue
                  ],
                ),
              ),
              titlePadding: const EdgeInsets.only(left: 16, bottom: 16),
              background: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Theme.of(context).colorScheme.primaryContainer,
                      Theme.of(context).colorScheme.surface,
                    ],
                  ),
                ),
              ),
            ),
          ),
          if (_isLoading)
            const SliverFillRemaining(
              child: Center(
                child: CircularProgressIndicator.adaptive(),
              ),
            )
          else if (_error != null)
            SliverFillRemaining(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.error_outline,
                      size: 48,
                      color: Theme.of(context).colorScheme.error,
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'Error loading categories',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      _error!,
                      style: Theme.of(context).textTheme.bodyMedium,
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 24),
                    FilledButton.icon(
                      onPressed: _loadCategories,
                      icon: const Icon(Icons.refresh),
                      label: const Text('Try Again'),
                    ),
                  ],
                ),
              ),
            )
          else
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Welcome back!',
                      style:
                          Theme.of(context).textTheme.headlineMedium?.copyWith(
                                fontWeight: FontWeight.bold,
                              ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Challenge yourself with our diverse collection of trivia categories.',
                      style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                            color:
                                Theme.of(context).colorScheme.onSurfaceVariant,
                          ),
                    ),
                    const SizedBox(height: 24),
                    SizedBox(
                      width: double.infinity,
                      child: TextField(
                        controller: _searchController,
                        decoration: InputDecoration(
                          hintText: 'Search categories...',
                          prefixIcon: Icon(
                            Icons.search,
                            color:
                                Theme.of(context).colorScheme.onSurfaceVariant,
                          ),
                          filled: true,
                          fillColor: Theme.of(context)
                              .colorScheme
                              .surfaceVariant
                              .withOpacity(0.3),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide(
                              color: Theme.of(context)
                                  .colorScheme
                                  .outline
                                  .withOpacity(0.2),
                            ),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide(
                              color: Theme.of(context)
                                  .colorScheme
                                  .outline
                                  .withOpacity(0.2),
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide(
                              color: Theme.of(context).colorScheme.primary,
                            ),
                          ),
                        ),
                        onChanged: _filterCategories,
                      ),
                    ),
                    const SizedBox(height: 24),
                    Text(
                      'Featured Categories',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                  ],
                ),
              ),
            ),
          SliverPadding(
            padding: const EdgeInsets.all(16),
            sliver: SliverGrid(
              delegate: SliverChildBuilderDelegate(
                (context, index) {
                  final category = _filteredCategories[index];
                  return _CategoryCard(
                    title: category['name'],
                    category: category['id'].toString(),
                    icon: _getCategoryIcon(category['name']),
                  );
                },
                childCount: _filteredCategories.length,
              ),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 16,
                crossAxisSpacing: 16,
                childAspectRatio: 1,
              ),
            ),
          ),
        ],
      ),
    );
  }

  IconData _getCategoryIcon(String categoryName) {
    final lowercaseName = categoryName.toLowerCase();
    if (lowercaseName.contains('entertainment: ')) {
      // Handle entertainment subcategories
      final subCategory = lowercaseName.replaceAll('entertainment: ', '');
      switch (subCategory) {
        case 'books':
          return Icons.menu_book;
        case 'film':
          return Icons.movie;
        case 'music':
          return Icons.music_note;
        case 'musicals & theatres':
          return Icons.theater_comedy;
        case 'television':
          return Icons.live_tv;
        case 'video games':
          return Icons.sports_esports;
        case 'board games':
          return Icons.casino;
        case 'japanese anime & manga':
          return Icons.animation;
        case 'cartoon & animations':
          return Icons.animation;
        case 'comics':
          return Icons.auto_stories;
        default:
          return Icons.theaters;
      }
    }

    // Handle science subcategories
    if (lowercaseName.contains('science: ')) {
      final subCategory = lowercaseName.replaceAll('science: ', '');
      switch (subCategory) {
        case 'computers':
          return Icons.computer;
        case 'mathematics':
          return Icons.functions;
        case 'gadgets':
          return Icons.devices;
        default:
          return Icons.science;
      }
    }

    // Handle other categories
    switch (lowercaseName) {
      case 'general knowledge':
        return Icons.psychology; // Brain icon for general knowledge
      case 'science & nature':
        return Icons.biotech; // DNA/lab icon for science & nature
      case 'mythology':
        return Icons.temple_buddhist; // Temple icon for mythology
      case 'sports':
        return Icons.emoji_events; // Trophy icon for sports
      case 'geography':
        return Icons.public; // Globe icon for geography
      case 'history':
        return Icons.history_edu; // Scroll/education icon for history
      case 'politics':
        return Icons.account_balance; // Government building for politics
      case 'art':
        return Icons.brush; // Paint brush for art
      case 'celebrities':
        return Icons.star; // Star for celebrities
      case 'animals':
        return Icons.cruelty_free; // Animal face icon for animals
      case 'vehicles':
        return Icons.precision_manufacturing; // Manufacturing/vehicle icon
      default:
        return Icons.lightbulb; // Fallback icon
    }
  }
}

class _CategoryCard extends StatelessWidget {
  final String title;
  final String category;
  final IconData icon;

  const _CategoryCard({
    required this.title,
    required this.category,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    final state = context.findAncestorStateOfType<_HomeScreenState>();
    final colors = state?._getCategoryColors(category) ??
        [
          Theme.of(context).colorScheme.primaryContainer,
          Theme.of(context).colorScheme.primaryContainer.withOpacity(0.7)
        ];

    return Card(
      elevation: 0,
      child: InkWell(
        onTap: () async {
          final model = context.read<TriviaModel>();
          await model.loadQuestions(category);
          if (context.mounted) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => const QuizScreen(),
              ),
            );
          }
        },
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: colors,
            ),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.3),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  icon,
                  size: 32,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                title,
                key: ValueKey('category_title_$title'),
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class GradientText extends StatelessWidget {
  const GradientText(
    this.text, {
    super.key,
    required this.gradient,
    this.style,
  });

  final String text;
  final TextStyle? style;
  final Gradient gradient;

  @override
  Widget build(BuildContext context) {
    return ShaderMask(
      blendMode: BlendMode.srcIn,
      shaderCallback: (bounds) => gradient.createShader(
        Rect.fromLTWH(0, 0, bounds.width, bounds.height),
      ),
      child: Text(
        text,
        style: style,
      ),
    );
  }
}
