import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

//This file defines the StorageService class, which manages local data persistence using SharedPreferences. It provides methods for saving and retrieving quiz history and results, allowing data to be retained across app launches
class StorageService {
  static const String _historyKey = 'trivia_history';
  static const String _resultsKey = 'quiz_results';

  Future<List<Map<String, dynamic>>> getHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final historyJson = prefs.getString(_historyKey);

    if (historyJson == null) {
      return [];
    }

    final List<dynamic> historyList = json.decode(historyJson);
    return historyList.map((item) => Map<String, dynamic>.from(item)).toList();
  }

  Future<void> saveHistory(List<Map<String, dynamic>> history) async {
    final prefs = await SharedPreferences.getInstance();
    final historyJson = json.encode(history);
    await prefs.setString(_historyKey, historyJson);
  }

  Future<void> saveResult(Map<String, dynamic> result) async {
    final prefs = await SharedPreferences.getInstance();
    List<String> results = prefs.getStringList(_resultsKey) ?? [];

    // Add the current date if not provided
    if (!result.containsKey('date')) {
      result['date'] = DateTime.now().toIso8601String();
    }

    results.add(jsonEncode(result));
    await prefs.setStringList(_resultsKey, results);
  }

  Future<List<Map<String, dynamic>>> getResults() async {
    final prefs = await SharedPreferences.getInstance();
    List<String> results = prefs.getStringList(_resultsKey) ?? [];

    return results.map((result) {
      final Map<String, dynamic> decoded = jsonDecode(result);
      if (decoded['date'] != null) {
        try {
          final date = DateTime.parse(decoded['date']);
          // Store the original date string
          decoded['originalDate'] = decoded['date'];
          // Format the date for display
          decoded['date'] =
              '${_getMonth(date.month)} ${date.day}, ${date.year}';
        } catch (e) {
          // If date parsing fails, use the raw date string or a fallback
          decoded['date'] = decoded['date'] ?? 'Unknown date';
        }
      }
      return decoded;
    }).toList();
  }

  Future<void> clearResults() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_resultsKey);
  }

  String _getMonth(int month) {
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec'
    ];
    return months[month - 1];
  }
}
