import 'dart:convert';
import 'package:http/http.dart' as http;

//This file contains the TriviaService class, which handles network requests to the Open Trivia Database API. It includes methods for fetching trivia questions, categories, and category question counts, as well as managing session tokens for API requests
class TriviaService {
  static const String _baseUrl = 'https://opentdb.com/api.php';
  static const String _tokenUrl = 'https://opentdb.com/api_token.php';
  String? _sessionToken;

  String _decodeQuestion(String text) {
    String decoded = Uri.decodeComponent(text);
    return decoded
        .replaceAll('&quot;', '"')
        .replaceAll('&#039;', "'")
        .replaceAll('&amp;', '&')
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>')
        .replaceAll('&deg;', '°')
        .replaceAll('&eacute;', 'é')
        .replaceAll('&ouml;', 'ö')
        .replaceAll('&ldquo;', '"')
        .replaceAll('&rdquo;', '"');
  }

  Future<void> _getSessionToken() async {
    if (_sessionToken == null) {
      final response = await http.get(Uri.parse('$_tokenUrl?command=request'));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['response_code'] == 0) {
          _sessionToken = data['token'];
        }
      }
    }
  }

  Future<void> _resetSessionToken() async {
    if (_sessionToken != null) {
      await http
          .get(Uri.parse('$_tokenUrl?command=reset&token=$_sessionToken'));
    }
    _sessionToken = null;
    await _getSessionToken();
  }

  Future<List<Map<String, dynamic>>> getQuestions(String category) async {
    await _getSessionToken();

    final queryParams = {
      'amount': '10',
      'type': 'multiple',
      'encode': 'url3986',
      if (category.isNotEmpty) 'category': category,
      if (_sessionToken != null) 'token': _sessionToken!,
    };

    final response = await http.get(
      Uri.parse(_baseUrl).replace(queryParameters: queryParams),
    );

    if (response.statusCode == 200) {
      final data = json.decode(response.body);

      switch (data['response_code']) {
        case 0: // Success
          final List<Map<String, dynamic>> questions = [];
          for (var question in data['results']) {
            questions.add({
              'question': _decodeQuestion(question['question']),
              'correct_answer': _decodeQuestion(question['correct_answer']),
              'incorrect_answers': (question['incorrect_answers'] as List)
                  .map((answer) => _decodeQuestion(answer))
                  .toList(),
            });
          }
          return questions;

        case 1: // No Results
          throw Exception('No questions available for this category');

        case 2: // Invalid Parameter
          throw Exception('Invalid parameters provided');

        case 3: // Token Not Found
          _sessionToken = null;
          await _getSessionToken();
          return getQuestions(category);

        case 4: // Token Empty
          await _resetSessionToken();
          return getQuestions(category);

        case 5: // Rate Limit
          await Future.delayed(const Duration(seconds: 5));
          return getQuestions(category);

        default:
          throw Exception('Unknown error occurred');
      }
    } else {
      throw Exception('Failed to load questions: ${response.statusCode}');
    }
  }

  Future<Map<String, dynamic>> getCategories() async {
    final response =
        await http.get(Uri.parse('https://opentdb.com/api_category.php'));

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      return data;
    } else {
      throw Exception('Failed to load categories: ${response.statusCode}');
    }
  }

  Future<Map<String, dynamic>> getCategoryQuestionCount(
      String categoryId) async {
    final response = await http.get(
      Uri.parse('https://opentdb.com/api_count.php?category=$categoryId'),
    );

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      return data;
    } else {
      throw Exception('Failed to load category count: ${response.statusCode}');
    }
  }
}
