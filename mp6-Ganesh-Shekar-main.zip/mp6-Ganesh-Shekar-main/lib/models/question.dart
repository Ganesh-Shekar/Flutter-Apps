//This file defines the Question class, which represents a trivia question. It includes properties for the question text, correct answer, and a list of incorrect answers, along with methods for converting to and from a map representation
class Question {
  final String question;
  final String correctAnswer;
  final List<String> incorrectAnswers;

  Question({
    required this.question,
    required this.correctAnswer,
    required this.incorrectAnswers,
  });

  Map<String, dynamic> toMap() {
    return {
      'question': question,
      'correct_answer': correctAnswer,
      'incorrect_answers': incorrectAnswers,
    };
  }

  factory Question.fromMap(Map<String, dynamic> map) {
    return Question(
      question: map['question'] as String,
      correctAnswer: map['correct_answer'] as String,
      incorrectAnswers: List<String>.from(map['incorrect_answers'] as List),
    );
  }
}
