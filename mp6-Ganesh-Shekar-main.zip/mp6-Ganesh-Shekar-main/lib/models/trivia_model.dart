import 'package:flutter/foundation.dart';
import '../services/trivia_service.dart';
import '../services/storage_service.dart';


// This file defines the TriviaModel class, which manages the state of the trivia quiz, including questions, score, and current question index. It uses the ChangeNotifier mixin to notify listeners of state changes, facilitating state management across the app
class TriviaModel with ChangeNotifier {
  final TriviaService _triviaService;
  final StorageService _storageService;

  List<Map<String, dynamic>> _questions = [];
  List<Map<String, dynamic>> _history = [];
  String _currentCategory = '';
  int _score = 0;
  int _currentQuestionIndex = 0;
  bool _isLoading = false;

  TriviaModel({
    TriviaService? triviaService,
    StorageService? storageService,
  })  : _triviaService = triviaService ?? TriviaService(),
        _storageService = storageService ?? StorageService() {
    _loadHistory();
  }

  List<Map<String, dynamic>> get questions => _questions;
  List<Map<String, dynamic>> get history => _history;
  String get currentCategory => _currentCategory;
  int get score => _score;
  int get currentQuestionIndex => _currentQuestionIndex;
  bool get isLoading => _isLoading;
  bool get isLastQuestion => _questions.isEmpty
      ? false
      : _currentQuestionIndex >= _questions.length - 1;
  Map<String, dynamic> get currentQuestion {
    if (_questions.isEmpty || _currentQuestionIndex >= _questions.length) {
      return {};
    }
    return _questions[_currentQuestionIndex];
  }

  // Setters for testing
  set questions(List<Map<String, dynamic>> value) {
    _questions = value;
    notifyListeners();
  }

  set currentCategory(String value) {
    _currentCategory = value;
    notifyListeners();
  }

  set score(int value) {
    _score = value;
    notifyListeners();
  }

  // Helper method for testing
  void setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }

  Future<void> loadQuestions(String category) async {
    _isLoading = true;
    _currentCategory = category;
    _currentQuestionIndex = 0;
    _score = 0;
    notifyListeners();

    try {
      _questions = await _triviaService.getQuestions(category);
    } catch (e) {
      _questions = [];
      print('Error loading questions: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  void answerQuestion(bool isCorrect) {
    if (isCorrect) {
      _score++;
    }
    if (_currentQuestionIndex < _questions.length - 1) {
      _currentQuestionIndex++;
    }
    notifyListeners();
  }

  Future<void> saveResult() async {
    if (_questions.isNotEmpty) {
      final result = {
        'category': _currentCategory,
        'score': _score,
        'totalQuestions': _questions.length,
        'date': DateTime.now().toIso8601String(),
      };
      await _storageService.saveResult(result);
      await _loadHistory();
    }
  }

  Future<void> _loadHistory() async {
    try {
      _history = await _storageService.getHistory();
      notifyListeners();
    } catch (e) {
      print('Error loading history: $e');
    }
  }
}
